(* ::Package:: *)

{\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(1\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(2\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(3\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(4\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(5\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==(-(1/y)-(2 \[Epsilon])/y) Subscript[B, 5][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(6\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(7\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==(-(1/y)-(2 \[Epsilon])/y) Subscript[B, 7][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(8\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(9\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(10\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(11\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(12\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(1/(1-y))-1/y) \[Epsilon]+(1/(1-y)+1/y) \[Epsilon]^2) Subscript[B, 1][x,y]-(\[Epsilon] Subscript[B, 5][x,y])/(2 (1-y))+(-(1/y)+(2/(1-y)+1/y) \[Epsilon]) Subscript[B, 12][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(13\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(14\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(15\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(16\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(17\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(18\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(19\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==-((3 \[Epsilon] Subscript[B, 5][x,y])/(2 y (x+y)))-(3 \[Epsilon] Subscript[B, 6][x,y])/(y (x+y))+(-(1/y)+(-(2/y)+1/(x+y)) \[Epsilon]) Subscript[B, 19][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(20\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==(\[Epsilon] Subscript[B, 12][x,y])/y-Subscript[B, 20][x,y]/y,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(21\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((1/(1-y)+1/y) \[Epsilon]+(-(1/(1-y))-1/y) \[Epsilon]^2) Subscript[B, 1][x,y]+(-(3/(1-y))-3/y) \[Epsilon] Subscript[B, 7][x,y]+(-(1/y)+(1/(1-y)+1/y) \[Epsilon]) Subscript[B, 21][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(22\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==(-(\[Epsilon]/(y (x+y)))+\[Epsilon]^2/(y (x+y))) Subscript[B, 1][x,y]+(1/y-1/(x+y)-1/(y (x+y))) \[Epsilon] Subscript[B, 2][x,y]+(-(1/(2 y))+1/(2 (x+y))-1/(2 y (x+y))) \[Epsilon] Subscript[B, 3][x,y]+(\[Epsilon] Subscript[B, 12][x,y])/(x+y)+(-(1/(x+y))+(-(2/y)+2/(x+y)) \[Epsilon]) Subscript[B, 22][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(23\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((2/((1-y) (x+y))+2/(y (x+y))) \[Epsilon]+(-(2/((1-y) (x+y)))-2/(y (x+y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(2 \[Epsilon] Subscript[B, 2][x,y])/(y (x+y))+(\[Epsilon] Subscript[B, 3][x,y])/(y (x+y))+(\[Epsilon] Subscript[B, 5][x,y])/((1-y) (x+y))-(4 \[Epsilon] Subscript[B, 12][x,y])/((1-y) (x+y))+(-(1/y)+(-(2/y)+2/(x+y)) \[Epsilon]) Subscript[B, 23][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(24\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(1/(1-y))+x/(2 (1-y))-3/(2 y)+x/(2 y)+1/(2 (x+y))) \[Epsilon]+(-(2/(1-y))+x/(1-y)-3/y+x/y+1/(x+y)) \[Epsilon]^2+(-(4/(1-y))+(2 x)/(1-y)-6/y+(2 x)/y+2/(x+y)) \[Epsilon]^3+(-(8/(1-y))+(4 x)/(1-y)-12/y+(4 x)/y+4/(x+y)) \[Epsilon]^4) Subscript[B, 2][x,y]+((-(1/(2 (1-y)))-x/(2 (1-y))-1/(2 y)-x/(2 y)) \[Epsilon]+(-(1/(1-y))-x/(1-y)-1/y-x/y) \[Epsilon]^2+(-(2/(1-y))-(2 x)/(1-y)-2/y-(2 x)/y) \[Epsilon]^3+(-(4/(1-y))-(4 x)/(1-y)-4/y-(4 x)/y) \[Epsilon]^4) Subscript[B, 3][x,y]+((-(3/(2 (1-y)))+1/(2 (x+y))) \[Epsilon]+(-(3/(1-y))+1/(x+y)) \[Epsilon]^2+(-(6/(1-y))+2/(x+y)) \[Epsilon]^3+(-(12/(1-y))+4/(x+y)) \[Epsilon]^4) Subscript[B, 7][x,y]+(-(1/y)+(3/(2 (1-y))+2/y-1/(2 (x+y))) \[Epsilon]) Subscript[B, 24][x,y]+((-(1/2)-1/(2 (1-y))-x/(2 (1-y))-1/(2 (x+y))+y/(2 (x+y))) \[Epsilon]+(-1-1/(1-y)-x/(1-y)-1/(x+y)+y/(x+y)) \[Epsilon]^2+(-2-2/(1-y)-(2 x)/(1-y)-2/(x+y)+(2 y)/(x+y)) \[Epsilon]^3+(-4-4/(1-y)-(4 x)/(1-y)-4/(x+y)+(4 y)/(x+y)) \[Epsilon]^4) Subscript[B, 25][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(25\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==(1/(2 (1-y))+1/(2 y)-3/(2 (1-y) (x+y))) \[Epsilon] Subscript[B, 2][x,y]+(-(1/(2 (1-y)))-1/(2 y)) \[Epsilon] Subscript[B, 3][x,y]-(3 \[Epsilon] Subscript[B, 7][x,y])/(2 (1-y) (x+y))+((3 \[Epsilon])/(2 (1-y) (x+y))-(3 \[Epsilon]^2)/((1-y) (x+y))) Subscript[B, 24][x,y]+(-(1/y)+(-(1/(2 (1-y)))-2/y+3/(2 (x+y))) \[Epsilon]) Subscript[B, 25][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(26\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(1/(2 y))+1/(2 (x+y))) \[Epsilon]+(-(1/y)+1/(x+y)) \[Epsilon]^2+(-(2/y)+2/(x+y)) \[Epsilon]^3+(-(4/y)+4/(x+y)) \[Epsilon]^4) Subscript[B, 8][x,y]+(-(\[Epsilon]/(x+y))-(2 \[Epsilon]^2)/(x+y)-(4 \[Epsilon]^3)/(x+y)-(8 \[Epsilon]^4)/(x+y)) Subscript[B, 12][x,y]+(-(1/(2 y))-1/(2 (x+y))) \[Epsilon] Subscript[B, 26][x,y]+((1/2+1/(x+y)-y/(2 (x+y))) \[Epsilon]+(1+2/(x+y)-y/(x+y)) \[Epsilon]^2+(2+4/(x+y)-(2 y)/(x+y)) \[Epsilon]^3+(4+8/(x+y)-(4 y)/(x+y)) \[Epsilon]^4) Subscript[B, 27][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(27\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((2/((1-y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon]+(-(2/((1-y) (4 (-1+y)+x y)))-2/(y (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(\[Epsilon] Subscript[B, 5][x,y])/((1-y) (4 (-1+y)+x y))+(-(3/(2 y^2))-3/(2 (-2+y) (x+y))+3/((-2+y) (4 (-1+y)+x y))-6/(y^2 (4 (-1+y)+x y))-3/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 8][x,y]+(2/y^2+8/(y^2 (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 9][x,y]+(3/((-2+y) (x+y))-4/((1-y) (4 (-1+y)+x y))-6/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 12][x,y]+((-(3/(2 y^2))+3/(2 (-2+y) (x+y))-3/((-2+y) (4 (-1+y)+x y))-6/(y^2 (4 (-1+y)+x y))+3/(y (4 (-1+y)+x y))) \[Epsilon]+(3/y^2-3/((-2+y) (x+y))+6/((-2+y) (4 (-1+y)+x y))+12/(y^2 (4 (-1+y)+x y))-6/(y (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 26][x,y]+(-(1/y)-2/(y (4 (-1+y)+x y))+(-(5/(2 y))+3/(2 (x+y))-8/(y (4 (-1+y)+x y))) \[Epsilon]) Subscript[B, 27][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(28\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(1/((1-y) (4 (-1+y)+x y)))-2/(y (4 (-1+y)+x y))) \[Epsilon]+(1/((1-y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(-(3/(2 (1-y) (x+y)))-3/(2 (-2+y) (x+y))+1/((1-y) (4 (-1+y)+x y))+3/((-2+y) (4 (-1+y)+x y))-1/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 2][x,y]+(1/(2 (1-y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 3][x,y]+(-(3/(2 (1-y) (x+y)))-3/(2 (-2+y) (x+y))+9/(2 (1-y) (4 (-1+y)+x y))+3/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 7][x,y]+(-((2 \[Epsilon])/(y (4 (-1+y)+x y)))+(4 \[Epsilon]^2)/(y (4 (-1+y)+x y))) Subscript[B, 10][x,y]+(2/y^2-2/((-2+y) (x+y))+4/((-2+y) (4 (-1+y)+x y))+8/(y^2 (4 (-1+y)+x y))-4/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 16][x,y]+(1/((-2+y) (x+y))-1/((1-y) (4 (-1+y)+x y))-2/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 21][x,y]+((3/(2 (1-y) (x+y))+3/(2 (-2+y) (x+y))-3/(2 (1-y) (4 (-1+y)+x y))-3/((-2+y) (4 (-1+y)+x y))) \[Epsilon]+(-(3/((1-y) (x+y)))-3/((-2+y) (x+y))+3/((1-y) (4 (-1+y)+x y))+6/((-2+y) (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 24][x,y]+(2/(y (4 (-1+y)+x y))+(-(1/(2 (-2+y) (x+y)))+1/(2 (1-y) (4 (-1+y)+x y))+1/((-2+y) (4 (-1+y)+x y))+8/(y (4 (-1+y)+x y))) \[Epsilon]) Subscript[B, 25][x,y]+(-(1/y)-2/(y (4 (-1+y)+x y))+(-(1/y)+1/(x+y)-4/(y (4 (-1+y)+x y))) \[Epsilon]) Subscript[B, 28][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(29\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==0,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(30\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((3/(4 x y^2)-3/(4 y^2 (x+y))) \[Epsilon]+(-(3/(4 x y^2))+3/(4 y^2 (x+y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(3/(4 x y^2)-3/(4 y^2 (x+y))-3/(4 y (x+y))) \[Epsilon] Subscript[B, 2][x,y]+(3/(8 x y^2)-3/(8 y^2 (x+y))+3/(8 y (x+y))) \[Epsilon] Subscript[B, 3][x,y]+(1/(8 x y)-1/(8 y (x+y))) \[Epsilon] Subscript[B, 5][x,y]+(1/(2 x y)-1/(2 y (x+y))) \[Epsilon] Subscript[B, 12][x,y]+(-(1/y)+1/(x+y)) \[Epsilon] Subscript[B, 14][x,y]+(-(1/(x y))+1/(y (x+y))) \[Epsilon] Subscript[B, 20][x,y]+(3 \[Epsilon] Subscript[B, 22][x,y])/(2 x y)+(1/(4 x y)+1/(4 (x+y))-1/(4 y (x+y))) \[Epsilon] Subscript[B, 23][x,y]+(-(1/y)+(-(2/y)+1/(x+y)) \[Epsilon]) Subscript[B, 30][x,y]+(\[Epsilon] Subscript[B, 31][x,y])/y,
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(31\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(1/(4 x (1-y)))+3/(2 x y^2)-1/(4 x y)-1/((1-y) (x+y))-3/(2 y^2 (x+y))-1/(y (x+y))) \[Epsilon]+(1/(4 x (1-y))-3/(2 x y^2)+1/(4 x y)+1/((1-y) (x+y))+3/(2 y^2 (x+y))+1/(y (x+y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(5/(4 (1-y))-1/(4 x (1-y))+3/(2 x y^2)+5/(4 y)-1/(4 x y)-1/((1-y) (x+y))-3/(2 y^2 (x+y))-5/(2 y (x+y))) \[Epsilon] Subscript[B, 2][x,y]+(-(5/(8 (1-y)))-1/(8 x (1-y))+3/(4 x y^2)-5/(8 y)-1/(8 x y)-3/(4 y^2 (x+y))+1/(4 y (x+y))) \[Epsilon] Subscript[B, 3][x,y]+(-(1/(1-y))-1/y-1/((1-y) (x+y))) \[Epsilon] Subscript[B, 4][x,y]+(1/(8 x (1-y))+1/(4 x y)-1/(4 y (x+y))) \[Epsilon] Subscript[B, 5][x,y]+(1/(1-y)+1/y+2/((1-y) (x+y))) \[Epsilon] Subscript[B, 6][x,y]+(1/(2 x (1-y))+1/(x y)-1/(y (x+y))) \[Epsilon] Subscript[B, 12][x,y]+(-(2/(1-y))-2/y+2/((1-y) (x+y))) \[Epsilon] Subscript[B, 13][x,y]+(-(2/(1-y))+x/(1-y)-2/y+x/y+2/((1-y) (x+y))) \[Epsilon] Subscript[B, 14][x,y]+(\[Epsilon] Subscript[B, 19][x,y])/(1-y)+(-(1/(x (1-y)))-2/(x y)+2/(y (x+y))) \[Epsilon] Subscript[B, 20][x,y]+(3/(2 (1-y))+3/(2 x (1-y))+3/(2 y)+3/(x y)) \[Epsilon] Subscript[B, 22][x,y]+(-(3/(4 (1-y)))+1/(4 x (1-y))+1/(2 x y)-1/(2 (x+y))-1/(2 y (x+y))) \[Epsilon] Subscript[B, 23][x,y]+(-(2/(1-y))-2/y+(-(5/(1-y))-6/y) \[Epsilon]) Subscript[B, 30][x,y]+(1/(1-y)+(3/(1-y)+3/y+1/(x+y)) \[Epsilon]) Subscript[B, 31][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(32\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((1/(2 (1-y) (x+y))+1/(2 y (x+y))+1/(4 y^2+x (1+y)^2)-2/((1-y) (4 y^2+x (1+y)^2))-3/(2 y (4 y^2+x (1+y)^2))) \[Epsilon]+(-(1/(2 (1-y) (x+y)))-1/(2 y (x+y))-1/(4 y^2+x (1+y)^2)+2/((1-y) (4 y^2+x (1+y)^2))+3/(2 y (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 1][x,y]+(3/(2 y)-3/(2 (1+y)^2)-3/(2 (1+y))-1/(2 (1-y) (x+y))+1/(2 y (x+y))-1/(4 y^2+x (1+y)^2)+2/((1-y) (4 y^2+x (1+y)^2))-3/(2 y (4 y^2+x (1+y)^2))+6/((1+y)^2 (4 y^2+x (1+y)^2))-6/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 2][x,y]+(-(1/(2 y))+3/(4 (1+y)^2)+1/(2 (1+y))+1/(4 y (x+y))-3/(2 (4 y^2+x (1+y)^2))-3/(4 y (4 y^2+x (1+y)^2))-3/((1+y)^2 (4 y^2+x (1+y)^2))+4/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 3][x,y]+(1/(4 (1-y) (x+y))+3/(4 (4 y^2+x (1+y)^2))-1/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 5][x,y]+(-(1/(2 y))+3/(1+y)^2+1/(2 (1+y))-1/(2 (1-y) (x+y))+2/((1-y) (4 y^2+x (1+y)^2))-12/((1+y)^2 (4 y^2+x (1+y)^2))+22/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 8][x,y]+(-(2/(1+y)^2)+8/((1+y)^2 (4 y^2+x (1+y)^2))-16/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 9][x,y]+((2 \[Epsilon])/(4 y^2+x (1+y)^2)-(4 \[Epsilon]^2)/(4 y^2+x (1+y)^2)) Subscript[B, 10][x,y]-(\[Epsilon] Subscript[B, 12][x,y])/(4 y^2+x (1+y)^2)+(1/y-1/(1+y)+1/((1-y) (x+y))-4/((1-y) (4 y^2+x (1+y)^2))+4/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 15][x,y]+(1/y-2/(1+y)^2-1/(1+y)-1/((1-y) (x+y))+4/((1-y) (4 y^2+x (1+y)^2))+8/((1+y)^2 (4 y^2+x (1+y)^2))-12/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 16][x,y]+(-(1/((1-y) (x+y)))-2/(4 y^2+x (1+y)^2)+4/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 20][x,y]+(-(3/y)+3/(1+y)^2+3/(1+y)-3/(4 y^2+x (1+y)^2)-12/((1+y)^2 (4 y^2+x (1+y)^2))+12/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 22][x,y]+(1/(2 (1+y)^2)-1/(2 (1+y))+1/(2 (x+y))-9/(2 (4 y^2+x (1+y)^2))-2/((1+y)^2 (4 y^2+x (1+y)^2))+6/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 23][x,y]+((-(3/(2 y))+3/(1+y)^2+3/(2 (1+y))+3/(2 (1-y) (x+y))-6/((1-y) (4 y^2+x (1+y)^2))-12/((1+y)^2 (4 y^2+x (1+y)^2))+18/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon]+(3/y-6/(1+y)^2-3/(1+y)-3/((1-y) (x+y))+12/((1-y) (4 y^2+x (1+y)^2))+24/((1+y)^2 (4 y^2+x (1+y)^2))-36/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 26][x,y]+(-(1/(1+y)^2)+3/(2 (1+y))-1/(2 (x+y))-1/(2 (1-y) (x+y))+8/(4 y^2+x (1+y)^2)+2/((1-y) (4 y^2+x (1+y)^2))+4/((1+y)^2 (4 y^2+x (1+y)^2))-14/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 27][x,y]+(-(1/(1+y))-4/(4 y^2+x (1+y)^2)+4/((1+y) (4 y^2+x (1+y)^2))+(1/y-2/(1+y)+1/(x+y)-8/(4 y^2+x (1+y)^2)+8/((1+y) (4 y^2+x (1+y)^2))) \[Epsilon]) Subscript[B, 32][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(33\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((9/(8 x (1-y))+13/(8 x y^2)+9/(8 x y)+13/(16 (-2+y) (x+y))-13/(8 y^2 (x+y))-13/(16 y (x+y))-9/(8 (1-y) (4 (-1+y)+x y))-13/(8 (-2+y) (4 (-1+y)+x y))) \[Epsilon]+(-(9/(8 x (1-y)))-13/(8 x y^2)-9/(8 x y)-13/(16 (-2+y) (x+y))+13/(8 y^2 (x+y))+13/(16 y (x+y))+9/(8 (1-y) (4 (-1+y)+x y))+13/(8 (-2+y) (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(1/(8 x (1-y))+13/(8 x y^2)+1/(8 x y)+31/(16 (-2+y) (x+y))-13/(8 y^2 (x+y))-31/(16 y (x+y))-1/(8 (1-y) (4 (-1+y)+x y))-31/(8 (-2+y) (4 (-1+y)+x y))+17/(4 y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 2][x,y]+(9/(16 x (1-y))+13/(16 x y^2)+9/(16 x y)-13/(32 (-2+y) (x+y))-13/(16 y^2 (x+y))+13/(32 y (x+y))-9/(16 (1-y) (4 (-1+y)+x y))+13/(16 (-2+y) (4 (-1+y)+x y))-5/(8 y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 3][x,y]+(-(1/(2 (-2+y) (x+y)))+1/(2 y (x+y))+1/((-2+y) (4 (-1+y)+x y))-1/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 4][x,y]+(3/(16 x (1-y))+3/(16 x y)+3/(16 (-2+y) (x+y))-3/(16 y (x+y))-3/(16 (1-y) (4 (-1+y)+x y))-3/(8 (-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 5][x,y]+(1/(2 (-2+y) (x+y))-1/(2 y (x+y))-1/((-2+y) (4 (-1+y)+x y))+1/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 6][x,y]+(-(6/(x (1-y)))-6/(x y)-1/((-2+y) (x+y))+1/(y (x+y))+6/((1-y) (4 (-1+y)+x y))+2/((-2+y) (4 (-1+y)+x y))+4/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 8][x,y]+(4/(x (1-y))+4/(x y)-4/((1-y) (4 (-1+y)+x y))-4/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 9][x,y]+((-(1/(x (1-y)))-1/(x y)+1/((1-y) (4 (-1+y)+x y))) \[Epsilon]+(2/(x (1-y))+2/(x y)-2/((1-y) (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 10][x,y]+(-(2/y^2)-8/(y^2 (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 11][x,y]+(3/(4 x (1-y))+3/(4 x y)+3/(4 (-2+y) (x+y))-3/(4 y (x+y))-3/(4 (1-y) (4 (-1+y)+x y))-3/(2 (-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 12][x,y]+(-(1/((-2+y) (x+y)))+1/(y (x+y))+2/((-2+y) (4 (-1+y)+x y))-2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 13][x,y]+(3/y^2-3/((-2+y) (x+y))+6/((-2+y) (4 (-1+y)+x y))+12/(y^2 (4 (-1+y)+x y))-6/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 14][x,y]+(1/((-2+y) (x+y))-1/(y (x+y))-2/((-2+y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 15][x,y]+(-(1/((-2+y) (x+y)))+1/(y (x+y))+2/((-2+y) (4 (-1+y)+x y))-2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 16][x,y]+((1/((-2+y) (x+y))-1/(y (x+y))-2/((-2+y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon]+(-(1/((-2+y) (x+y)))+1/(y (x+y))+2/((-2+y) (4 (-1+y)+x y))-2/(y (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 17][x,y]+(-(2/y^2)-8/(y^2 (4 (-1+y)+x y))+4/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 18][x,y]+(1/(3 (-2+y) (x+y))-2/(3 (-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 19][x,y]+(-(3/(2 x (1-y)))-3/(2 x y)-3/(2 (-2+y) (x+y))+3/(2 y (x+y))+3/(2 (1-y) (4 (-1+y)+x y))+3/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 20][x,y]+(9/(4 x (1-y))+9/(4 x y)+2/((-2+y) (x+y))-2/(y (x+y))-9/(4 (1-y) (4 (-1+y)+x y))-4/((-2+y) (4 (-1+y)+x y))-1/(2 y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 22][x,y]+(3/(8 x (1-y))+3/(8 x y)-3/(8 (-2+y) (x+y))-3/(8 y (x+y))-3/(8 (1-y) (4 (-1+y)+x y))+3/(4 (-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 23][x,y]+((1/((-2+y) (x+y))-1/(y (x+y))-2/((-2+y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon]+(-(2/((-2+y) (x+y)))+2/(y (x+y))+4/((-2+y) (4 (-1+y)+x y))-4/(y (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 26][x,y]+(1/y^2-1/(y (x+y))+4/(y^2 (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 29][x,y]+(1/(y (x+y))+2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 30][x,y]+(-(1/(2 (-2+y) (x+y)))-1/(2 y (x+y))+1/((-2+y) (4 (-1+y)+x y))-1/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 31][x,y]+(-(1/((-2+y) (x+y)))+1/(y (x+y))+2/((-2+y) (4 (-1+y)+x y))+2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 32][x,y]+(-(1/y)-2/(y (4 (-1+y)+x y))+(-(1/y)+1/(x+y)) \[Epsilon]) Subscript[B, 33][x,y]+(-(3/y^2)+1/(y (x+y))-12/(y^2 (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 35][x,y]+(-(1/((-2+y) (x+y)))+1/(y (x+y))+2/((-2+y) (4 (-1+y)+x y))-2/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 36][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(34\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(7/(4 x y^2))+7/(4 y^2 (x+y))) \[Epsilon]+(7/(4 x y^2)-7/(4 y^2 (x+y))) \[Epsilon]^2) Subscript[B, 1][x,y]+(-(7/(4 x y^2))+7/(4 y^2 (x+y))+3/(4 y (x+y))) \[Epsilon] Subscript[B, 2][x,y]+(-(7/(8 x y^2))+7/(8 y^2 (x+y))-7/(8 y (x+y))) \[Epsilon] Subscript[B, 3][x,y]-(\[Epsilon] Subscript[B, 4][x,y])/(y (x+y))+(-(1/(8 x y))+1/(8 y (x+y))) \[Epsilon] Subscript[B, 5][x,y]+(\[Epsilon] Subscript[B, 6][x,y])/(y (x+y))-(\[Epsilon] Subscript[B, 8][x,y])/(y (x+y))+(-(1/(2 x y))+1/(2 y (x+y))) \[Epsilon] Subscript[B, 12][x,y]-(2 \[Epsilon] Subscript[B, 13][x,y])/(y (x+y))+(1/y-1/(x+y)) \[Epsilon] Subscript[B, 14][x,y]-(2 \[Epsilon] Subscript[B, 16][x,y])/(y (x+y))+(\[Epsilon] Subscript[B, 17][x,y])/(y (x+y))+(\[Epsilon] Subscript[B, 19][x,y])/(3 (x+y))+(1/(x y)-1/(y (x+y))) \[Epsilon] Subscript[B, 20][x,y]+(-(3/(2 x y))+4/(y (x+y))) \[Epsilon] Subscript[B, 22][x,y]+(-(1/(4 x y))-1/(4 (x+y))+1/(4 y (x+y))) \[Epsilon] Subscript[B, 23][x,y]+((2 \[Epsilon])/(y (x+y))-(4 \[Epsilon]^2)/(y (x+y))) Subscript[B, 26][x,y]+(1/y-1/(x+y)+2/(y (x+y))) \[Epsilon] Subscript[B, 29][x,y]+(1/(x+y)-2/(y (x+y))) \[Epsilon] Subscript[B, 30][x,y]+(-(1/(x+y))+1/(y (x+y))) \[Epsilon] Subscript[B, 31][x,y]-(2 \[Epsilon] Subscript[B, 32][x,y])/(y (x+y))+(-(1/y)+1/(x+y)) \[Epsilon] Subscript[B, 34][x,y]+(-(1/y)+1/(x+y)-2/(y (x+y))) \[Epsilon] Subscript[B, 35][x,y]-(2 \[Epsilon] Subscript[B, 36][x,y])/(y (x+y)),
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(35\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((1/(12 x (-1-2 y))+13/(12 x (1-y))-1/(8 x (-1-2 y) (1-y))+3/(4 x y^2)+9/(8 x y)+1/((1-y) (x+y))+13/(8 (-2+y) (x+y))-5/(8 y (x+y))-1/(2 (4 (-1+y)+x y))-1/(12 (-1-2 y) (4 (-1+y)+x y))-13/(12 (1-y) (4 (-1+y)+x y))+1/(8 (-1-2 y) (1-y) (4 (-1+y)+x y))-13/(4 (-2+y) (4 (-1+y)+x y))+5/(4 (4 y^2+x (1+y)^2))-4/((1-y) (4 y^2+x (1+y)^2))-3/(4 y^2 (4 y^2+x (1+y)^2))-2/(y (4 y^2+x (1+y)^2))+y/(2 (4 y^2+x (1+y)^2))) \[Epsilon]+(-(1/(12 x (-1-2 y)))-13/(12 x (1-y))+1/(8 x (-1-2 y) (1-y))-3/(4 x y^2)-9/(8 x y)-1/((1-y) (x+y))-13/(8 (-2+y) (x+y))+5/(8 y (x+y))+1/(2 (4 (-1+y)+x y))+1/(12 (-1-2 y) (4 (-1+y)+x y))+13/(12 (1-y) (4 (-1+y)+x y))-1/(8 (-1-2 y) (1-y) (4 (-1+y)+x y))+13/(4 (-2+y) (4 (-1+y)+x y))-5/(4 (4 y^2+x (1+y)^2))+4/((1-y) (4 y^2+x (1+y)^2))+3/(4 y^2 (4 y^2+x (1+y)^2))+2/(y (4 y^2+x (1+y)^2))-y/(2 (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 1][x,y]+(1/(8 x (1-y))+3/(4 x y^2)+1/(8 x y)-1/((1-y) (x+y))+31/(8 (-2+y) (x+y))-5/(8 y (x+y))+1/(2 (4 (-1+y)+x y))-1/(8 (1-y) (4 (-1+y)+x y))-31/(4 (-2+y) (4 (-1+y)+x y))-23/(4 (4 y^2+x (1+y)^2))+4/((1-y) (4 y^2+x (1+y)^2))-3/(4 y^2 (4 y^2+x (1+y)^2))-1/(y (4 y^2+x (1+y)^2))-y/(2 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 2][x,y]+(9/(16 x (1-y))+3/(8 x y^2)+9/(16 x y)-13/(16 (-2+y) (x+y))-5/(16 y (x+y))+3/(4 (4 (-1+y)+x y))-9/(16 (1-y) (4 (-1+y)+x y))+13/(8 (-2+y) (4 (-1+y)+x y))+1/(8 (4 y^2+x (1+y)^2))-3/(8 y^2 (4 y^2+x (1+y)^2))-1/(y (4 y^2+x (1+y)^2))-(3 y)/(4 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 3][x,y]+(-(1/((-2+y) (x+y)))+2/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 4][x,y]+(3/(16 x (1-y))+1/(8 x y)+1/(2 (1-y) (x+y))+3/(8 (-2+y) (x+y))-3/(16 (4 (-1+y)+x y))-3/(16 (1-y) (4 (-1+y)+x y))-3/(4 (-2+y) (4 (-1+y)+x y))+5/(4 (4 y^2+x (1+y)^2))-2/((1-y) (4 y^2+x (1+y)^2))-1/(8 y (4 y^2+x (1+y)^2))+(3 y)/(8 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 5][x,y]+(1/((-2+y) (x+y))-2/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 6][x,y]+(-(6/(x (1-y)))-6/(x y)-1/((1-y) (x+y))-2/((-2+y) (x+y))+6/((1-y) (4 (-1+y)+x y))+4/((-2+y) (4 (-1+y)+x y))+10/(4 y^2+x (1+y)^2)+4/((1-y) (4 y^2+x (1+y)^2))+6/(y (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 8][x,y]+(4/(x (1-y))+4/(x y)-4/((1-y) (4 (-1+y)+x y))-8/(4 y^2+x (1+y)^2)-4/(y (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 9][x,y]+((-(1/(x (1-y)))-1/(x y)-1/(4 (-1+y)+x y)+1/((1-y) (4 (-1+y)+x y))+2/(4 y^2+x (1+y)^2)+1/(y (4 y^2+x (1+y)^2))+y/(4 y^2+x (1+y)^2)) \[Epsilon]+(2/(x (1-y))+2/(x y)+2/(4 (-1+y)+x y)-2/((1-y) (4 (-1+y)+x y))-4/(4 y^2+x (1+y)^2)-2/(y (4 y^2+x (1+y)^2))-(2 y)/(4 y^2+x (1+y)^2)) \[Epsilon]^2) Subscript[B, 10][x,y]+(-(2/y)-8/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 11][x,y]+(3/(4 x (1-y))+1/(2 x y)+3/(2 (-2+y) (x+y))-3/(4 (4 (-1+y)+x y))-3/(4 (1-y) (4 (-1+y)+x y))-3/((-2+y) (4 (-1+y)+x y))-1/(4 y^2+x (1+y)^2)-1/(2 y (4 y^2+x (1+y)^2))-y/(2 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 12][x,y]+(-(2/((-2+y) (x+y)))+4/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 13][x,y]+(3/y-3/(x+y)-6/((-2+y) (x+y))+12/((-2+y) (4 (-1+y)+x y))+12/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 14][x,y]+(2/((1-y) (x+y))+2/((-2+y) (x+y))-4/((-2+y) (4 (-1+y)+x y))+4/(4 y^2+x (1+y)^2)-8/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 15][x,y]+(-(2/((1-y) (x+y)))-2/((-2+y) (x+y))+4/((-2+y) (4 (-1+y)+x y))-8/(4 y^2+x (1+y)^2)+8/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 16][x,y]+((2/((-2+y) (x+y))-4/((-2+y) (4 (-1+y)+x y))) \[Epsilon]+(-(2/((-2+y) (x+y)))+4/((-2+y) (4 (-1+y)+x y))) \[Epsilon]^2) Subscript[B, 17][x,y]+(-(2/y)+4/(4 (-1+y)+x y)-8/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 18][x,y]+(1/(3 (x+y))+2/(3 (-2+y) (x+y))-2/(3 (4 (-1+y)+x y))-4/(3 (-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 19][x,y]+(-(3/(2 x (1-y)))-1/(x y)-2/((1-y) (x+y))-3/((-2+y) (x+y))+3/(2 (4 (-1+y)+x y))+3/(2 (1-y) (4 (-1+y)+x y))+6/((-2+y) (4 (-1+y)+x y))-4/(4 y^2+x (1+y)^2)+8/((1-y) (4 y^2+x (1+y)^2))+1/(y (4 y^2+x (1+y)^2))-y/(4 y^2+x (1+y)^2)) \[Epsilon] Subscript[B, 20][x,y]+(9/(4 x (1-y))+3/(2 x y)+4/((-2+y) (x+y))-9/(4 (4 (-1+y)+x y))-9/(4 (1-y) (4 (-1+y)+x y))-8/((-2+y) (4 (-1+y)+x y))+3/(4 y^2+x (1+y)^2)-3/(2 y (4 y^2+x (1+y)^2))-(3 y)/(2 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 22][x,y]+(3/(8 x (1-y))+1/(4 x y)+1/(4 (x+y))-3/(4 (-2+y) (x+y))+9/(8 (4 (-1+y)+x y))-3/(8 (1-y) (4 (-1+y)+x y))+3/(2 (-2+y) (4 (-1+y)+x y))-3/(2 (4 y^2+x (1+y)^2))-1/(4 y (4 y^2+x (1+y)^2))-(9 y)/(4 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 23][x,y]+((3/((1-y) (x+y))+2/((-2+y) (x+y))-4/((-2+y) (4 (-1+y)+x y))+12/(4 y^2+x (1+y)^2)-12/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon]+(-(6/((1-y) (x+y)))-4/((-2+y) (x+y))+8/((-2+y) (4 (-1+y)+x y))-24/(4 y^2+x (1+y)^2)+24/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 26][x,y]+(-(1/(x+y))-1/((1-y) (x+y))+4/((1-y) (4 y^2+x (1+y)^2))+(4 y)/(4 y^2+x (1+y)^2)) \[Epsilon] Subscript[B, 27][x,y]+(4 \[Epsilon] Subscript[B, 29][x,y])/(y (4 (-1+y)+x y))+(1/(x+y)+2/(4 (-1+y)+x y)) \[Epsilon] Subscript[B, 30][x,y]+(-(1/(x+y))-1/((-2+y) (x+y))+2/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 31][x,y]+(-(2/(4 y^2+x (1+y)^2))-(2 y)/(4 y^2+x (1+y)^2)+(-(2/((-2+y) (x+y)))+4/(4 (-1+y)+x y)+4/((-2+y) (4 (-1+y)+x y))-4/(4 y^2+x (1+y)^2)-(4 y)/(4 y^2+x (1+y)^2)) \[Epsilon]) Subscript[B, 32][x,y]-(2 Subscript[B, 33][x,y])/(4 (-1+y)+x y)+(-(2/y)+2/(x+y)-12/(y (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 35][x,y]+(-(2/((-2+y) (x+y)))+4/((-2+y) (4 (-1+y)+x y))) \[Epsilon] Subscript[B, 36][x,y],
\!\(\*SuperscriptBox[
SubscriptBox[\(B\), \(36\)], 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[x,y]==((-(3/(4 x y^2))+3/(4 x y)-1/((1-y) (x+y))-5/(4 y (x+y))-5/(4 (4 y^2+x (1+y)^2))+4/((1-y) (4 y^2+x (1+y)^2))+3/(4 y^2 (4 y^2+x (1+y)^2))+2/(y (4 y^2+x (1+y)^2))-y/(2 (4 y^2+x (1+y)^2))) \[Epsilon]+(3/(4 x y^2)-3/(4 x y)+1/((1-y) (x+y))+5/(4 y (x+y))+5/(4 (4 y^2+x (1+y)^2))-4/((1-y) (4 y^2+x (1+y)^2))-3/(4 y^2 (4 y^2+x (1+y)^2))-2/(y (4 y^2+x (1+y)^2))+y/(2 (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 1][x,y]+(-(3/(4 x y^2))+7/(4 x y)-1/(4 (x+y))+1/((1-y) (x+y))-5/(4 y (x+y))+23/(4 (4 y^2+x (1+y)^2))-4/((1-y) (4 y^2+x (1+y)^2))+3/(4 y^2 (4 y^2+x (1+y)^2))+1/(y (4 y^2+x (1+y)^2))+y/(2 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 2][x,y]+(-(3/(8 x y^2))+3/(8 x y)+1/(8 (x+y))-5/(8 y (x+y))-1/(8 (4 y^2+x (1+y)^2))+3/(8 y^2 (4 y^2+x (1+y)^2))+1/(y (4 y^2+x (1+y)^2))+(3 y)/(4 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 3][x,y]-(\[Epsilon] Subscript[B, 4][x,y])/(x+y)+(-(1/(8 x))-1/(8 x y)+1/(8 (x+y))-1/(2 (1-y) (x+y))-5/(4 (4 y^2+x (1+y)^2))+2/((1-y) (4 y^2+x (1+y)^2))+1/(8 y (4 y^2+x (1+y)^2))-(3 y)/(8 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 5][x,y]+(\[Epsilon] Subscript[B, 6][x,y])/(x+y)+(6/(x y)+1/((1-y) (x+y))-10/(4 y^2+x (1+y)^2)-4/((1-y) (4 y^2+x (1+y)^2))-6/(y (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 8][x,y]+(-(4/(x y))+8/(4 y^2+x (1+y)^2)+4/(y (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 9][x,y]+((1/(x y)-2/(4 y^2+x (1+y)^2)-1/(y (4 y^2+x (1+y)^2))-y/(4 y^2+x (1+y)^2)) \[Epsilon]+(-(2/(x y))+4/(4 y^2+x (1+y)^2)+2/(y (4 y^2+x (1+y)^2))+(2 y)/(4 y^2+x (1+y)^2)) \[Epsilon]^2) Subscript[B, 10][x,y]+(-(1/(2 x))-1/(2 x y)+1/(2 (x+y))+1/(4 y^2+x (1+y)^2)+1/(2 y (4 y^2+x (1+y)^2))+y/(2 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 12][x,y]+(1-y/(x+y)) \[Epsilon] Subscript[B, 14][x,y]+(-(2/((1-y) (x+y)))-4/(4 y^2+x (1+y)^2)+8/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 15][x,y]+(2/((1-y) (x+y))+8/(4 y^2+x (1+y)^2)-8/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 16][x,y]+(\[Epsilon]/(x+y)+(-(1/y)-1/(x+y)) \[Epsilon]^2) Subscript[B, 17][x,y]-Subscript[B, 18][x,y]+(y \[Epsilon] Subscript[B, 19][x,y])/(3 (x+y))+(1/x+1/(x y)-1/(x+y)+2/((1-y) (x+y))+4/(4 y^2+x (1+y)^2)-8/((1-y) (4 y^2+x (1+y)^2))-1/(y (4 y^2+x (1+y)^2))+y/(4 y^2+x (1+y)^2)) \[Epsilon] Subscript[B, 20][x,y]+(-(2/(x+y))+(-(3/(2 x))-3/(2 x y)+6/(x+y)-3/(4 y^2+x (1+y)^2)+3/(2 y (4 y^2+x (1+y)^2))+(3 y)/(2 (4 y^2+x (1+y)^2))) \[Epsilon]) Subscript[B, 22][x,y]+(-(1/(4 x))-1/(4 x y)-3/(4 (x+y))-y/(4 (x+y))+3/(2 (4 y^2+x (1+y)^2))+1/(4 y (4 y^2+x (1+y)^2))+(9 y)/(4 (4 y^2+x (1+y)^2))) \[Epsilon] Subscript[B, 23][x,y]+((-(1/(x+y))-3/((1-y) (x+y))-12/(4 y^2+x (1+y)^2)+12/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon]+(2/(x+y)+6/((1-y) (x+y))+24/(4 y^2+x (1+y)^2)-24/((1-y) (4 y^2+x (1+y)^2))) \[Epsilon]^2) Subscript[B, 26][x,y]+(3/(x+y)+1/((1-y) (x+y))-y/(x+y)-4/((1-y) (4 y^2+x (1+y)^2))-(4 y)/(4 y^2+x (1+y)^2)) \[Epsilon] Subscript[B, 27][x,y]+(-(2/(x+y))+y/(x+y)) \[Epsilon] Subscript[B, 30][x,y]+(1/(x+y)-y/(x+y)) \[Epsilon] Subscript[B, 31][x,y]+(2/(4 y^2+x (1+y)^2)+(2 y)/(4 y^2+x (1+y)^2)+(-(2/(x+y))+4/(4 y^2+x (1+y)^2)+(4 y)/(4 y^2+x (1+y)^2)) \[Epsilon]) Subscript[B, 32][x,y]+(-1-2/(x+y)+y/(x+y)) \[Epsilon] Subscript[B, 35][x,y]+(1/y-1/(x+y)) \[Epsilon] Subscript[B, 36][x,y]}
