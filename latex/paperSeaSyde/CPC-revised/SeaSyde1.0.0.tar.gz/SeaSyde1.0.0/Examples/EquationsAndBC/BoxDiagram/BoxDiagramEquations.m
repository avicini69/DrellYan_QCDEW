(* ::Package:: *)

{\!\(\*SuperscriptBox[\(j[A16w, 0, 0, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 0, 1, 0, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 1, 0, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==(2 (2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13]-(4 mW^2-2 s12 \[Epsilon]) j[A16w,1,0,1,0][s12,s13])/(2 (4 mW^2-s12) s12),
\!\(\*SuperscriptBox[\(j[A16w, 0, 1, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 1, 0, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==(-2 (2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13]+mW^2 (4 (1-2 \[Epsilon]) j[A16w,1,0,1,0][s12,s13]-(4 mW^2-s12) (2-2 \[Epsilon]) j[A16w,1,0,1,1][s12,s13]))/(2 mW^2 (4 mW^2-s12) s12),
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 0, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==(-2 (2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13]+mW^2 (4 (1-2 \[Epsilon]) j[A16w,1,0,1,0][s12,s13]-(4 mW^2-s12) (2-2 \[Epsilon]) j[A16w,1,1,1,0][s12,s13]))/(2 mW^2 (4 mW^2-s12) s12),
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"1", ",", "0"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==1/2 (-((4 (2 mW^2-s12) (2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13])/(mW^2 (4 mW^2-s12) s12 (4 mW^4+4 mW^2 s13-s12 s13)))-(4 (1-2 \[Epsilon]) j[A16w,0,1,0,1][s12,s13])/(s12 (-4 mW^4-4 mW^2 s13+s12 s13))+(2 s13 (2 mW^2+s13) \[Epsilon] j[A16w,0,1,1,1][s12,s13])/(s12 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))-(4 (1-2 \[Epsilon]) j[A16w,1,0,1,0][s12,s13])/((4 mW^2-s12) (4 mW^4+4 mW^2 s13-s12 s13))+(2 (2 mW^2+s12+2 s13) \[Epsilon] j[A16w,1,0,1,1][s12,s13])/((s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))+(2 s13 (2 mW^2+s13) \[Epsilon] j[A16w,1,1,0,1][s12,s13])/(s12 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))+(2 (2 mW^2+s12+2 s13) \[Epsilon] j[A16w,1,1,1,0][s12,s13])/((s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))+((s12 s13 (-2 s12+s13 (-2-2 \[Epsilon]))+4 mW^4 (s13+s12 (1-2 \[Epsilon]))+4 mW^2 s13 (s13+s12 (1-2 \[Epsilon]))) j[A16w,1,1,1,1][s12,s13])/(s12 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))),
\!\(\*SuperscriptBox[\(j[A16w, 0, 0, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 0, 1, 0, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==-((\[Epsilon] j[A16w,0,1,0,1][s12,s13])/s13),
\!\(\*SuperscriptBox[\(j[A16w, 1, 0, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 0, 1, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==((2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13]-mW^2 (2 (1-2 \[Epsilon]) j[A16w,0,1,0,1][s12,s13]+(2 s13+mW^2 (2-2 \[Epsilon])) j[A16w,0,1,1,1][s12,s13]))/(2 mW^2 s13 (mW^2+s13)),
\!\(\*SuperscriptBox[\(j[A16w, 1, 0, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 0, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==((2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13]-mW^2 (2 (1-2 \[Epsilon]) j[A16w,0,1,0,1][s12,s13]+(2 s13+mW^2 (2-2 \[Epsilon])) j[A16w,1,1,0,1][s12,s13]))/(2 mW^2 s13 (mW^2+s13)),
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 1, 0]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==0,
\!\(\*SuperscriptBox[\(j[A16w, 1, 1, 1, 1]\), 
TagBox[
RowBox[{"(", 
RowBox[{"0", ",", "1"}], ")"}],
Derivative],
MultilineFunction->None]\)[s12,s13]==1/2 (-((2 (2 mW^2+s13) (2-2 \[Epsilon]) j[A16w,0,0,1,0][s12,s13])/(mW^2 s13 (mW^2+s13) (4 mW^4+4 mW^2 s13-s12 s13)))+(4 mW^2 (1-2 \[Epsilon]) j[A16w,0,1,0,1][s12,s13])/(s13 (mW^2+s13) (4 mW^4+4 mW^2 s13-s12 s13))+(2 (2 mW^4+3 mW^2 s13-s12 s13) \[Epsilon] j[A16w,0,1,1,1][s12,s13])/((mW^2+s13) (s12+s13) (4 mW^4+4 mW^2 s13-s12 s13))+(4 (1-2 \[Epsilon]) j[A16w,1,0,1,0][s12,s13])/(s13 (4 mW^4+4 mW^2 s13-s12 s13))-(2 (2 mW^2-s12) s12 \[Epsilon] j[A16w,1,0,1,1][s12,s13])/(s13 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))+(2 (2 mW^4+3 mW^2 s13-s12 s13) \[Epsilon] j[A16w,1,1,0,1][s12,s13])/((mW^2+s13) (s12+s13) (4 mW^4+4 mW^2 s13-s12 s13))-(2 (2 mW^2-s12) s12 \[Epsilon] j[A16w,1,1,1,0][s12,s13])/(s13 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13))+((4 mW^2 s13 (2 s13-s12 (-2-2 \[Epsilon]))+s12 s13 (-2 s13+s12 (-2-2 \[Epsilon]))+4 mW^4 (s12+s13 (1-2 \[Epsilon]))) j[A16w,1,1,1,1][s12,s13])/(s13 (s12+s13) (-4 mW^4-4 mW^2 s13+s12 s13)))}
