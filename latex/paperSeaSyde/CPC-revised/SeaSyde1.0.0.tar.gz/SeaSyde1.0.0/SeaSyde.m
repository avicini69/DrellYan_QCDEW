(* ::Package:: *)

(* ::Input::Initialization:: *)
(* SeaSyde is a free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>. *)

(* This software is maintained on ______________ *)

ClearSystemCache[];
Unprotect@@Names["SeaSyde`*"];
ClearAll@@Names["SeaSyde`*"];
ClearAll@@Names["SeaSyde`Private`*"];

BeginPackage["SeaSyde`"];
Print["+++++ SeaSyde` +++++\nVersion 1.0.0"];
Print["SeaSyde is a package for solving the system of differential equation associated to the Master Integrals of a given topology."];
Print["For any question or comment, please contact: \n",Hyperlink["T. Armadillo","mailto:tommaso.armadillo@uclouvain.be"],", ",Hyperlink["R. Bonciani","mailto:roberto.bonciani@roma1.infn.it"],", ",Hyperlink["S. Devoto","mailto:simone.devoto@unimi.it"],", ",Hyperlink["N. Rana","mailto:narayan.rana@unimi.it"]," or ",Hyperlink["A. Vicini","mailto:alessandro.vicini@mi.infn.it"],"."];
Print["For the latest version please see the ",Hyperlink["GitHub repository","https://github.com/TommasoArmadillo/SeaSyde"],"."];

(* Begin Documentation *)
CurrentConfiguration::usage="CurrentConfiguration[]. Returns the current configuration for all the internal parameters.";
UpdateConfiguration::usage="UpdateConfiguration[NewConfiguration_]. Updates the current configuration. NewConfiguration must be a list of replacement rules, e.g. ParameterName -> newvalue. For the complete list of the parameters and their default value please refer to the documentation.";
ReadFrom::usage="ReadFrom[\"Path/to/file.m\"]. Utility function to read the content from a file *.m";
\[Epsilon]::usage="Symbol representing the dimensional regulator.";
eps::usage="Alternative symbol for the dimensional regulator. It is converted into \[Epsilon] in the code.";
GetPoint::usage="GetPoint[]. Get the point at which the boundary conditions are imposed.";
SolutionValue::usage="SolutionValue[]. Returns the value of the solution at the centre of the series expansion (i.e. GetPoint[]). Note that all the numbers are given with InternalWorkingPrecision digits. If it is unreadble consider using //N. To see only the nth MI use SolutionValue[][[n]].";
SolutionTable::usage="SolutionValue[]. Returns the value of the solution at the centre of the series expansion (i.e. GetPoint[]) as a List. Note that all the numbers are given with InternalWorkingPrecision digits. If it is unreadble consider using //N. To see only the mth \[Epsilon]-coefficient of the nth MI use SolutionTable[][[n,m]].";
Solution::usage="Solution[]. Returns the full solution to the system of differential equations. Note that all the coefficient are given with InternalWorkingPrecision digits. If it is unreadble consider using //N. To see only the nth MI use Solution[][[n]].";
SolutionExpanded::usage="SolutionExpanded[]. Get the full solution after applying a M\[ODoubleDot]bius transformation. Note that all the numbers are given with InternalWorkingPrecision digits. If it is unreadble consider using //N. To see only the nth MI use SolutionValue[][[n]].";
SolveSystem::usage="SolveSystem[var_]. Solve the system of differential equations w.r.t. the variable var. The center of the series will be the point in which the BCs are imposed (i.e. GetPoint[]).";
SetSystemOfDifferentialEquation::usage="SetSystemOfDifferentialEquation[SystemOfEqs_, BCs_, MIs_, Variables_, PointBC_, Param_:{}]. Sets all the internal variables of the package and prepare the system of differential equations. To see the format in which every argoument should be given please refer to the documentation of the package.";
GetSystemOfDifferentialEquation::usage="GetSystemOfDifferentialEquation[]. Returns the system of differential equations togheter with the boundary conditions. If there are n MIs, the first n elements of the list are the equations w.r.t. the first kinematic variable, the second n equations are the ones w.r.t. to the second kinematic variable and so on. The last n elements are the BCs of the system.";
GetSystemOfDifferentialEquationExpanded::usage="GetSystemOfDifferentialEquationExpanded[]. Returns the system of differential equations after it has been \[Epsilon]-expanded. The output list has m elements, where m is the number of order in \[Epsilon] we are considering. The m-th element of the list contains the equations relevant for that particoular order and their corresponding BCs.";
TransportBoundaryConditions::usage="TransportBoundaryConditions[PhaseSpacePoint_List]. Transport the BCs for all the variables from the starting point (i.e. GetPoint[]) to PhaseSpacePoint. PhaseSpacePoint must be a List whose length is given by the number of kinematic variables. Its first element must be the final value for the first variable, its second element the value for the second variable, and so on. After transporting the boundary conditions, the point in which they are imposed is updated to PhaseSpacePoint.";
TransportVariable::usage="TransportVariable[Var_,Destination_,Line_:{}]. Transport the BCs for the variable Var from the starting point (i.e. GetPoint[]) to Destination. Note that the Destination point can be an arbitrary complex number. If the Line parameter is given, it will follow that line. Otherwise an internal algortihm will determine the best path to avoid singularities and branch-cuts. The line object can be created through the function CreateLine.";
CreateLine::usage="CreateLine[Points_List]. Returns an object line which connects all the points in Points through segments. Points must be a list of arbitrary complex points, the first one must be the one in which the BCs are imposed (i.e. GetPoint[]), the last one must be the Destination point.";
CreateGraph::usage="CreateGraph[MiNum_,EpsOrder_,left_,right_,OtherFunctions_:{}]. Plot the O(\!\(\*SuperscriptBox[\(\[Epsilon]\), \(EpsOrder\)]\)) for the MiNum-th Master Integral from left to right. Other functions can be passed in the OtherFunctions argoument in order to be plotted in the same graph.";
PerformMobiusTransformation::usage="PerformMobiusTransformation[Var_]. Perform a M\[ODoubleDot]bius tranformation of the solution w.r.t. the variable Var. A M\[ODoubleDot]bius transformation extend the interval of convergence of a serie from (\!\(\*SubscriptBox[\(x\), \(0\)]\)-r,\!\(\*SubscriptBox[\(x\), \(0\)]\)+r) to (\!\(\*SubscriptBox[\(x\), \(L\)]\),\!\(\*SubscriptBox[\(x\), \(R\)]\)), where \!\(\*SubscriptBox[\(x\), \(L\)]\)and \!\(\*SubscriptBox[\(x\), \(R\)]\) are the nearest singular points, by mapping the interval (\!\(\*SubscriptBox[\(x\), \(L\)]\),\!\(\*SubscriptBox[\(x\), \(R\)]\)) into (-1,1). Note that 0 must be inside (\!\(\*SubscriptBox[\(x\), \(L\)]\),\!\(\*SubscriptBox[\(x\), \(R\)]\)).";
CheckSingularities::usage="CheckSingularities[]. Check if the singularities have a logarithmic behaviour, i.e. if they are associated to a branch-cut. It may be very time consuming.";
(* End Documentation *)

Begin["`Private`"];

(* Switch off some warnings *)
Off[Reduce::ratnz];
Off[NSolve::ratnz];
Off[Solve::ratnz];
Off[General::stop];
Off[General::munfl];
Off[NRoots`Isolate::maxit];

(* Define some variables Global so that accessing the solution one sees x and not SeaSyde`Private`x *)
eps:=\[Epsilon];
x:=Global`x;
s:=Global`s;
t:=Global`t;
y:=Global`y;
tInt:=Global`tInt;

(* Functions for analytic continuation *)
Subscript[\[Theta], p][x_]:=HeavisideTheta[x];
Subscript[\[Theta], m][x_]:=HeavisideTheta[-x];

(* Configuration *)
PackageConfiguration={
"EpsilonOrder"->2,
	"ExpansionOrder"->50,
"InternalWorkingPrecision"->250,
"ChopPrecision"->100,
"LogarithmicExpansion"->False,
"RadiusOfConvergence"-> 2,
"LogarithmicSingularities"->{},
"SafeSingularities"->{}
}//Association;

UpdateConfiguration[l_List]:=UpdateConfiguration[l//Association];
UpdateConfiguration[newConfig_Association]:=Module[{newConf,keys,key,list},
list=newConfig//Normal;
newConf=Table[(list[[i,1]]//ToString)->list[[i,2]],{i,1,Length[list]}]//Association;
keys=ToString/@Keys[newConfig];
Do[
key=keys[[i]];
If[KeyExistsQ[PackageConfiguration,key], 
PackageConfiguration[key]=newConf[key];
PrintInfo["Updated ", key, " parameter, new value -> ",newConf[key]];
,
PrintWarning["Key ",key, " does not exist!"];
];
,{i,1,Length[newConfig]}];
];

CurrentConfiguration[]:=PackageConfiguration

EpsilonOrderPrivate := PackageConfiguration["EpsilonOrder"];
ExpansionOrderPrivate := PackageConfiguration["ExpansionOrder"];
MethodIntegrationPrivate := PackageConfiguration["MethodIntegration"];
InternalWorkingPrecisionPrivate:=PackageConfiguration["InternalWorkingPrecision"];
ChopPrecisionPrivate:=PackageConfiguration["ChopPrecision"];
LogarithmicExpansionPrivate:=PackageConfiguration["LogarithmicExpansion"];
RadiusOfConvergencePrivate:=PackageConfiguration["RadiusOfConvergence"];
LogarithmicSingularities:=PackageConfiguration["LogarithmicSingularities"];
SafeSingularities:=PackageConfiguration["SafeSingularities"];

(* Print informations and errors *)
PrintInfo[args__]:=Print["SeaSyde: ",args];
PrintWarning[args__]:=Print[Style["SeaSyde Warning: ",Orange],args];
PrintError[mes__]:=(Print[Style["SeaSyde ERROR: ",Red],mes];Abort[];);

(* Internal variables. The function Reset is called inside SetSystemOfDifferentialEquations *)
Reset[]:=Module[{},
SystemOfDifferentialEquation = {};
SystemEpsilonExpanded = {};
MasterIntegrals= {};
MasterIntegralsFunctions={};         (* {Subscript[B, 1][x],Subscript[B, 2][x]} *)
MasterIntegralsPrototype={};        (* {Overscript[Subscript[B, 1], 0][x]+Overscript[Subscript[B, 1], 1][x] \[Epsilon]+Overscript[Subscript[B, 1], 2][x]\[Epsilon]^2,Overscript[Subscript[B, 2], 0][x]+Overscript[Subscript[B, 2], 1][x] \[Epsilon]+ Overscript[Subscript[B, 2], 2][x] \[Epsilon]^2} *)
Singularities = {};                              (* {{singularities for variable 1}, {singularities for variable 2}} *)
MasterIntegralsMobius={};
VariablesEq={x};
CurrentBC={0};
line={tInt};
lineParam=tInt;
DeltaPrescription={};
MinEpsExponent=0;
CurrentExpansionPoint=0;
CurrentBCLineParam = 0;
NumberMasterIntegrals=1;
LastKinematicVariableUsed=x;
KinematicParameters={};
AsymptoticBoundaryConditions=False;
AsymptoticVariable=x;
CheckSingularitiesDone=False;
MaxLogOrder=0;
ErrorEstimate=0;
];

(* Set the system and get it *)
SetSystemOfDifferentialEquation[EquationsExt_List,BoundaryConditionsExt_List,UnknownExt_List,Variable_List,PointBC_List,Parameters_List:{}]:=Module[{Equations=EquationsExt,BoundaryConditions=BoundaryConditionsExt,Unknown=UnknownExt,Substitutions={},multipleLists},
Reset[];
KinematicParameters=Parameters;
Equations=(((#/.{Equal->Subtract})==0&)/@Equations);
BoundaryConditions=(((#/.{Equal->Subtract})==0&)/@BoundaryConditions);
VariablesEq=Variable/.Global`\[Delta]->0;
PrintInfo["There are ",VariablesEq//Length," kinematics variables ",VariablesEq];
DeltaPrescription=Table[If[Arg[Coefficient[Variable[[i]],Global`\[Delta]]]>=0,1,-1],{i,1,Length[Variable]}];
PrintInfo["The Feynman prescriptions for the variables are ",Table[If[DeltaPrescription[[i]]==1,+I Global`\[Delta], -I Global`\[Delta]],{i,1,Length[DeltaPrescription]}]];

(* Note that if the MI do explicitly depend on \[Epsilon] we remove it *)
Do[Substitutions=Join[{
GetName[Unknown[[i]]][var___,VariablesEq[[-1]],\[Epsilon]]->GetName[Unknown[[i]]][var,VariablesEq[[-1]]],
GetName[Unknown[[i]]][var___,PointBC[[-1]],\[Epsilon]]->GetName[Unknown[[i]]][var,PointBC[[-1]]],
Derivative[d__,last_][GetName[Unknown[[i]]]][var___,VariablesEq[[-1]],\[Epsilon]]->Derivative[d][GetName[Unknown[[i]]]][var,VariablesEq[[-1]]]
},Substitutions],{i,1,Length[Unknown]}];
Unknown=Unknown/.Substitutions;
Equations=Equations/.Substitutions;
BoundaryConditions=BoundaryConditions/.Substitutions;

MasterIntegralsFunctions=Unknown;
MasterIntegralsPrototype=Unknown;
MasterIntegrals=Unknown;
NumberMasterIntegrals=Length[MasterIntegrals];
PrintInfo["There are ",NumberMasterIntegrals, " Master Integrals"];
CurrentBC= (PointBC/.KinematicParameters)//SetPrec;
PrintInfo["The boundary conditions are imposed in ",(LogicalExpand[VariablesEq==CurrentBC]/.And->List)//N];
DetermineAsymptoticBC[BoundaryConditions,VariablesEq];
If[AsymptoticBoundaryConditions, 
PrintInfo["The boundary conditions are given as asymptotic limit. Note that the first solution of the system must be with respect to ", AsymptoticVariable];
,
PrintInfo["The boundary conditions are given as precise value of the solution."];
];
SystemOfDifferentialEquation=(Join[Equations,BoundaryConditions]/.KinematicParameters);
PrintInfo["There are ",Length[Equations], " equations and ", Length[BoundaryConditions], " boundary conditions"];
Singularities=FindSingularities[Equations,VariablesEq]/.KinematicParameters;
PrintInfo["The possible singularities for the kinematics variables ",VariablesEq," are respectively ",Singularities//N];
MinEpsExponent=FindMinEpsilonExponent[BoundaryConditions];
EpsilonExpandDiffEq[];
PrintInfo["The system of differential equation has been set and expanded in \[Epsilon]"];

multipleLists=Table[{},{i,1,Length[VariablesEq]}];
If[(MatchQ[SafeSingularities,{}]||MatchQ[SafeSingularities,multipleLists])||(MatchQ[LogarithmicSingularities,{}]||MatchQ[LogarithmicSingularities,multipleLists]),
PackageConfiguration["LogarithmicSingularities"]=Singularities;
,
CheckSingularitiesDone=True;
];
If[MatchQ[SafeSingularities,{}],PackageConfiguration["SafeSingularities"]=multipleLists;];
If[MatchQ[LogarithmicSingularities,{}],PackageConfiguration["LogarithmicSingularities"]=multipleLists;];
];

EpsilonExpandDiffEq[]:=Module[{expansionSubstitutionFunctions,expansionSubstitutionDerivatives,system,systemExpanded, orderEps=EpsilonOrderPrivate,terms,exponent,i,j},
MasterIntegralsPrototype=MasterIntegralsFunctions;
expansionSubstitutionFunctions=Table[GetName[MasterIntegralsFunctions[[i]]][var__]->Sum[\!\(\*OverscriptBox[\((GetName[MasterIntegralsFunctions[\([\)\(i\)\(]\)]])\), \((j)\)]\)[var]eps^j,{j,MinEpsExponent,orderEps}],{i,1,Length[MasterIntegralsFunctions]}];
 expansionSubstitutionDerivatives=Table[Derivative[d__][GetName[MasterIntegralsFunctions[[i]]]][var__]->Sum[Derivative[d][\!\(\*OverscriptBox[\((GetName[MasterIntegralsFunctions[\([\)\(i\)\(]\)]])\), \((j)\)]\)][var]eps^j,{j,MinEpsExponent,orderEps}],{i,1,Length[MasterIntegralsFunctions]}];
system=Normal[Series[#,{eps,0,orderEps+1}]]&/@SystemOfDifferentialEquation;
system=system/.Join[expansionSubstitutionFunctions,expansionSubstitutionDerivatives];
systemExpanded=Table[Table[0,Length[system]],orderEps+Abs[MinEpsExponent]+1];
Do[
(* For better handling, the first index refers to # eq while the second one get the LeftHandSide *)
terms=system[[i,1]]//ChopDigits//Expand;
Do[
exponent=Exponent[terms[[j]],eps];
If[exponent>EpsilonOrderPrivate,Continue[];];
systemExpanded[[exponent+Abs[MinEpsExponent]+1,i]] +=Coefficient[terms[[j]],eps,exponent];
,{j,1,Length[terms]}];
,{i,1,Length[system]}];
SystemEpsilonExpanded=Map[Function[x,Equal[x,0]],systemExpanded,{2}];
MasterIntegralsPrototype=Table[Table[\!\(\*OverscriptBox[\(GetName[MasterIntegralsFunctions[\([\)\(j\)\(]\)]]\), \(i\)]\)[(VariablesEq/.{List->Sequence})],{j,1,Length[MasterIntegralsFunctions]}],{i,MinEpsExponent,orderEps}];
];


UpdateSystemEpsilonExpanded[]:=Module[{expansionSubstitutionFunctions,newBoundaryConditions},	
SystemEpsilonExpanded=Drop[#1,-NumberMasterIntegrals]& /@SystemEpsilonExpanded;	
expansionSubstitutionFunctions=
Table[GetName[MasterIntegralsFunctions[[i]]][var__]->Sum[\!\(\*OverscriptBox[\((GetName[MasterIntegralsFunctions[\([\)\(i\)\(]\)]])\), \((j)\)]\)[var]eps^j,{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,Length[MasterIntegralsFunctions]}];
newBoundaryConditions=SystemOfDifferentialEquation[[-NumberMasterIntegrals;;-1]]/.expansionSubstitutionFunctions;
newBoundaryConditions=newBoundaryConditions/.Equal->Subtract;		
Do[		
Do[	
AppendTo[SystemEpsilonExpanded[[i+Abs[MinEpsExponent]+1]], Coefficient[newBoundaryConditions[[j]],eps,i]==0];		
,{j,1,NumberMasterIntegrals}];	
,{i,MinEpsExponent,EpsilonOrderPrivate}];
];


GetSystemOfDifferentialEquation[]:=Module[{},
SystemOfDifferentialEquation
];

GetSystemOfDifferentialEquationExpanded[]:=Module[{},
SystemEpsilonExpanded
];

(* Utility functions *)
Num:=N[#,InternalWorkingPrecisionPrivate]&;
NumAlmost:=N[#,100]&;    (* Usefull in some boundary conditions *)
ChopDigits:=Chop[#,10^-ChopPrecisionPrivate]&;
ChopLine:=Chop[#,10^-50]&;
SetPrec:=SetPrecision[#,InternalWorkingPrecisionPrivate]&;
SetAccur:=SetAccuracy[#,InternalWorkingPrecisionPrivate]&;

ReadFrom[Path_String]:=Module[{Content={}},
If[$FrontEnd=!=Null,SetDirectory[NotebookDirectory[]]];
Content=Quiet@Check[Get[Path],$Failed];
If[MatchQ[Content,$Failed], PrintError["File ", Path, " does not exists or it is empty, check if it is spelled correctly and try again."];];
PrintInfo["File ", Path, " has been correctly read."];
Content
];

FindMinEpsilonExponent[Boundary_]:=Module[{MinExp=0},
Do[
MinExp=Min[Exponent[Boundary[[i,1]],eps,Min],MinExp];
,{i,1,Length[Boundary]}];
MinExp
];

FindSingularities[SystemEquations_,Variables_]:=Module[{Singularities,AllEquations,DenominatorEquation,SingularPoints},
AllEquations=SystemEquations/.{Equal->Subtract};
Singularities=Table[{},{i,1,Length[Variables]}];
AllEquations=DeleteCases[AllEquations,Except[Plus[_,__]]];
AllEquations=AllEquations/.\!\(\*
TagBox[
StyleBox[
RowBox[{
RowBox[{
RowBox[{"Derivative", "[", "__", "]"}], "[", "_", "]"}], "[", "__", "]"}],
ShowSpecialCharacters->False,
ShowStringCharacters->True,
NumberMarks->True],
FullForm]\)->0;

Do[
	AllEquations=Collect[AllEquations,MasterIntegralsFunctions[[i]]];
,{i,1,Length[MasterIntegralsFunctions]}];

Do[
AllEquations[[i,0]]=List;
,{i,1,Length[AllEquations]}];

AllEquations=AllEquations//Together//Denominator//Flatten//DeleteDuplicates;

Do[
	Do[
		SingularPoints=Solve[AllEquations[[j]]==0,Variables[[i]],Complexes];
		Singularities[[i]]=Join[Singularities[[i]],SingularPoints/.{List[Rule[_,val_]]->val}];
	,{j,1,Length[AllEquations]}];
Singularities[[i]]=Singularities[[i]]//DeleteDuplicates;
,{i,1,Length[Variables]}];
Singularities
];

DetermineAsymptoticBC[BoundaryConditionsToStudy_,VariablesOfEquations_]:=Module[{},
Do[
If[FindVar[BoundaryConditionsToStudy, VariablesOfEquations[[i]]],
AsymptoticBoundaryConditions=True;
AsymptoticVariable=VariablesOfEquations[[i]];
Break[];
];
,{i,1,Length[VariablesOfEquations]}];
];

FindVar[expr_, var_] := Module[{temp},
	temp = Hold[expr] /. var -> 0;
	If[temp === Hold[expr], False, True]
];

GetName[f_[x__]]:=f;
GetVariable[f_[var_,___]]:=var;

MyDerivative[Unknown_,variables_,line_,lineParam_,i_,f_]:=Module[{var},
var=GetVariable[Unknown[[i]]];
Return[D[Unknown[[i]],variables]->1/D[line,lineParam] Subscript[f, i]'[lineParam]];
];

(* Solve the system of differential equations *)
SolveSystem[variable_]:=SolveSeriesExpansion[tInt,variable,True];

SolveSeriesExpansion[line_,variable_,CalledFromNotebook_Symbol:True]:=Module[{EpsOrder=MinEpsExponent,Sol,Equation,BC,var,AlreadySolved={},tmp,numMI=Length[MasterIntegralsFunctions],lineParam=tInt,index=1,OtherVarBC={},correctionOrder},

If[AsymptoticBoundaryConditions && !MatchQ[variable,AsymptoticVariable],PrintError["The boundary conditions are given as asymptotic limit for ",AsymptoticVariable,", the system can not be solved with respect to ",variable];
];
LastKinematicVariableUsed=variable;   (* This will be useful for CreateGraph *)

If[CalledFromNotebook,
Do[
If[MatchQ[variable,VariablesEq[[i]]],
CurrentExpansionPoint=Solve[line== (CurrentBC[[i]]), lineParam,WorkingPrecision->InternalWorkingPrecisionPrivate][[1,1,2]]//Chop;
CurrentBCLineParam =CurrentExpansionPoint;
Break[];
];
,{i,1,Length[VariablesEq]}];
];
Do[
If[MatchQ[variable,VariablesEq[[i]]],
Break[];
];
index += NumberMasterIntegrals;
,{i,1,Length[VariablesEq]}];

(* Correction to the order of resolution*)
correctionOrder=Min[Exponent[SystemOfDifferentialEquation[[index;;index+NumberMasterIntegrals-1]]/.{Equal->Subtract},variable,Min]];
If[correctionOrder<0,PackageConfiguration["ExpansionOrder"]-=correctionOrder;];

SeaSyde`Private`Debug`EpsOrder=MinEpsExponent;
Do[
If[CalledFromNotebook,Print["Solving equation for \[Epsilon] order ",EpsOrder];];
tmp=SystemEpsilonExpanded[[n]];
Equation=tmp[[index;;index+NumberMasterIntegrals-1]];
BC=tmp[[-NumberMasterIntegrals;;-1]];

(* Substitute other variable value *)
Do[
If[!MatchQ[variable,VariablesEq[[i]]],
OtherVarBC=Join[OtherVarBC,{VariablesEq[[i]]-> CurrentBC[[i]]}];
];
,{i,1,Length[VariablesEq]}];
Equation=Equation/.OtherVarBC;
BC=BC/.OtherVarBC;
var=MasterIntegralsPrototype[[n]]/.OtherVarBC;

Sol=SolveEquation[Equation,BC,var,variable,EpsOrder,line, lineParam,CurrentExpansionPoint,AlreadySolved]//Num//ChopDigits;
AlreadySolved=Join[AlreadySolved,Table[var[[i]]->Sol[[i]],{i,1,Length[var]}]];
EpsOrder++;
SeaSyde`Private`Debug`EpsOrder++;
,{n,1,Length[SystemEpsilonExpanded]}];

MasterIntegrals=MasterIntegralsFunctions/.Table[GetName[MasterIntegralsFunctions[[i]]][var__]->Sum[\!\(\*OverscriptBox[\((GetName[MasterIntegralsFunctions[\([\)\(i\)\(]\)]])\), \((j)\)]\)[var]eps^j,{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,Length[MasterIntegralsFunctions]}];
MasterIntegrals=MasterIntegrals/.OtherVarBC;
MasterIntegrals=MasterIntegrals/.AlreadySolved;
MasterIntegrals=AnalyticContinuation[MasterIntegrals,variable,line,CurrentExpansionPoint];

(* Correction due to the order *)
If[correctionOrder<0,PackageConfiguration["ExpansionOrder"]+=correctionOrder;ClearSeries[MasterIntegrals,variable];];

If[CalledFromNotebook,Print["I solved the system of equation. The error estimate is: ",EstimateError[variable],"."];];
];

SolveEquation[EquationExt_, BoundaryConditions_,  Unknown_,KinVariable_,EpsOrder_,line_,lineParam_,PointExpansion_,AlreadySolved_:{}]:=Module[{Eq,newUnknown,newDerivatives,newFunctions,BC,newBC,solution={},oldVar,coeffDerivative,substitution={}},
(* Substitute already solved equations *)
Eq=EquationExt/.AlreadySolved;
(* Substitute functions *)
newUnknown=Table[Unknown[[i]]->Subscript[f, i][lineParam],{i,1,Length[Unknown]}];
newFunctions=Table[Subscript[f, i][lineParam],{i,1,Length[Unknown]}];
newDerivatives=Table[MyDerivative[Unknown,KinVariable,line,lineParam,i,f],{i,1,Length[Unknown]}];
Eq=Eq/.Join[newUnknown,newDerivatives];
(* Substitute line *)
Eq=Eq/.{KinVariable->line};

(* Substitute BC *)
newBC=(Table[GetName[Unknown[[i]]][__]->Subscript[f, i][lineParam],{i,1,Length[Unknown]}]/.Join[{KinVariable-> (line/.{lineParam-> PointExpansion})},{lineParam->PointExpansion}]);
BC=Solve[(BoundaryConditions)/.newBC,Table[newBC[[i,2]],{i,1,Length[BoundaryConditions]}],WorkingPrecision->InternalWorkingPrecisionPrivate][[1]]/.{Rule-> Equal};
BC=Sort[BC,#1[[1,0,2]]<#2[[1,0,2]]&];
BC=BC/.{KinVariable->line};

(* Make sure the coefficient of derivatives is 1 *)
Do[
coeffDerivative=Coefficient[Eq[[i,1]],Subscript[f, i]'[lineParam]]//Simplify;
Eq[[i]]=MultiplySides[Eq[[i]],1/coeffDerivative];
,{i,1,Length[Eq]}];

(* Solve *)
SeaSyde`Private`Debug`MInumber=0;
Do[
SeaSyde`Private`Debug`MInumber++;
If[FindVar[Eq[[i]],Subscript[f, j_]/;j>i],PrintError["The system is not given in triangular form. In particular MI: ",SeaSyde`Private`Debug`MInumber,", \[Epsilon] order: ",SeaSyde`Private`Debug`EpsOrder];];
solution=Join[solution,SolveEquationBySeriesExpansion[{Eq[[i]]/.substitution}//ChopDigits,{BC[[i]]},{newFunctions[[i]]},lineParam,PointExpansion,line,KinVariable]];
substitution=Join[substitution,{Subscript[f, i][lineParam]->solution[[-1]]}];
,{i,1,Length[Eq]}];
(* Get back to original variables *)
oldVar=Solve[KinVariable== line,lineParam][[1]]//Expand;
solution/.oldVar
];

DetermineR[Equations_,var_,varNumber_,pointExpansion_]:=Module[{polynomial,minExp,solOrd,RValues={},counter=1,ind,chopExp},
RValues={};
Do[
chopExp=Join[Cases[Equations,Power[var,a_]:> a,Infinity],Cases[Equations,Power[var+b_,a_]:> a,Infinity]]//Sort//First;
polynomial=Equations /. {Power[var, b_] /; b >chopExp -> 0, Power[var + a_, b_] /; b >chopExp -> 0};
If[pointExpansion==0,
polynomial=polynomial[[i,1]]/.{var->l}//Expand;
,
polynomial=polynomial[[i,1]]/.{(var+a_)->l}//Expand;
];
polynomial=polynomial/.RValues;
minExp=Exponent[polynomial,l,Min]//Chop;
counter=1;
While[NumericQ[minExp[[counter]]],counter++;];
solOrd=Solve[(Coefficient[polynomial,l,minExp[[counter]]]/.l->0)==0,r,WorkingPrecision->10];
RValues=Append[RValues,solOrd[[1,1]]];
,{i,1,Length[Equations]}];
Do[RValues[[i,2]]=Round[RValues[[i,2]],1/2],{i,1,RValues//Length}];
RValues
];

(* Example: Subscript[r, 1]>0 \[Rule] 1/1000*)
InequalityToNumber[sol_]:=Module[{\[Delta]=1*^-3,b=sol[[2]]},
If[MatchQ[sol, SubMinus[r]<_], Return[b+\[Delta]],Return[b-\[Delta]]];
];

(* Example {{Subscript[r, 1]\[Rule]0,Subscript[c, 1,0]\[Rule]1/4}} \[Rule] 0 *)
EqualityToNumber[sol_]:=Module[{solutions=sol[[1]],val},
Do[
If[MatchQ[solutions[[i,1]],Subscript[r, _]], val=solutions[[i,2]];];
,{i,1,Length[solutions]}];
val
];

SolveFrobenius[EquationExtF_,FunctionsF_,LineParamF_,PointExpansionF_]:=Module[{Equation = EquationExtF,Solution,RRules,BC,min,max,sol,coeff,order,unknownCoeff,index=1,CompleteSol,returnValue},
(* Substitute ansatz Subscript[f, i][x] \[Rule] x^rUnderscript[\[Sum], j] c[j]x^j*)
Solution={((#-PointExpansionF)^r Sum[c[j](#-PointExpansionF)^j,{j,0,ExpansionOrderPrivate+5}]&)[LineParamF]};
Equation=Equation/.{Subscript[f, i_]->((#-PointExpansionF)^r Sum[c[j](#-PointExpansionF)^j,{j,0,ExpansionOrderPrivate+5}]&)};
Equation=Normal[Series[Equation,{LineParamF,PointExpansionF,ExpansionOrderPrivate+5}]];        

RRules= DetermineR[Equation,LineParamF, Length[FunctionsF],PointExpansionF];
(* substitute R values in Solution and Equation *)
Solution=Solution/.RRules;
Equation = (Equation /.RRules)//ChopDigits;

(* Solve order by order *)
Equation=Equation/.{LineParamF-> z+PointExpansionF,c[0]->1}//ChopDigits//Expand;     

(* Note that we substitute Subscript[c, _,0]\[Rule]1 because the solution will depend by it and temporarily eliminating it we can speed up computation *)
Equation=ClearSeries[Equation,z]//ChopDigits;    (* Remove all terms of the type z^b where b>MaxOrder *)
min=RRules[[1,2]];
max=ExpansionOrderPrivate;
order=min;
Equation=Equation[[1]]/.{Equal->Subtract};

CompleteSol={c[0]->1};
While[order<=  max,
coeff=Coefficient[Equation,z,order];
coeff=(coeff/.CompleteSol)//ChopDigits;

unknownCoeff=c[index];
sol=Replace[coeff,{a_*unknownCoeff->0,unknownCoeff->0,a_*unknownCoeff+b__->-b/a, unknownCoeff+b__->-b}];
sol=Rule[unknownCoeff,sol//ChopDigits];
AppendTo[CompleteSol,sol];
order++;
index++;
];
returnValue=((Solution/.CompleteSol)/.c[i_]/;i>= max->0);
If[DependsQ[returnValue//Chop,c[_]],PrintError["Something went wrong while solving the homogeneous equation"];];
Return[returnValue/.c[_]->0];
];

SolveEquationBySeriesExpansion[EquationExt_,BoundaryConditionExt_,Functions_,LineParam_,PointExpansion_,LineParametrization_,KinVariab_]:=Module[{BoundaryCondition,BCs,Homogeneus,HomogeneusSolution,ParticoularSolution,Inhomogenues,CompleteSolution,InverseHomogeneusSeries,InhomogenuesSeries,Integrand,IntegratedSeries,DefiniteIntegratedSeries,points,limits,BCPoint},
BoundaryCondition=BoundaryConditionExt/.{LineParam->sInt+PointExpansion}/.{Log[coeff_*sInt]->Log[coeff]+Log[sInt]}//Expand;

Homogeneus=MakeHomogeneus[EquationExt,Functions[[1]]];

Inhomogenues=InomogeusPart[EquationExt];
Inhomogenues=(((Inhomogenues/.{LineParam->sInt+PointExpansion})/.{Log[x_]:>Log[Expand[x]]})/.{Power[x_,exp_]:>Power[Expand[x],exp]})//Num//ChopDigits//SetPrec;

HomogeneusSolution=SolveFrobenius[Homogeneus,Functions,LineParam,PointExpansion]//Num;
BCPoint=CurrentBCLineParam-PointExpansion//ChopDigits;
HomogeneusSolution=(HomogeneusSolution/.{LineParam->sInt+PointExpansion})//ChopDigits;

InverseHomogeneusSeries=Table[Series[(1/HomogeneusSolution[[i]])//Num,{sInt,0,ExpansionOrderPrivate+2}]//Normal,{i,1,Length[HomogeneusSolution]}]//Num;

InhomogenuesSeries=Table[FastSeries[Inhomogenues[[i]],sInt,0,ExpansionOrderPrivate+2],{i,1,Length[Inhomogenues]}]//SetPrec//Num;

Integrand=Table[ClearSeries[(InverseHomogeneusSeries[[i]]*InhomogenuesSeries[[i]])//ChopDigits//Expand,sInt],{i,1,Length[HomogeneusSolution]}]//Num;
IntegratedSeries= Table[MyIntegrate[Integrand[[i]]],{i,1,Length[HomogeneusSolution]}];

DefiniteIntegratedSeries=Table[(IntegratedSeries[[i]]),{i,1,Length[HomogeneusSolution]}]//Num;

ParticoularSolution=Table[
ClearSeries[HomogeneusSolution[[i]]*DefiniteIntegratedSeries[[i]]//ChopDigits//Expand,sInt]
,{i,1,Length[HomogeneusSolution]}]//Num;
CompleteSolution=Table[ClearSeries[(C[i]*HomogeneusSolution[[i]]+ParticoularSolution[[i]])//ChopDigits//Expand,sInt],{i,1,Length[HomogeneusSolution]}]//Num;
(* determine BC *)
limits=Table[0,{i,1,Length[BoundaryCondition]}];
BCs=Table[Null,{i,1,Length[BoundaryCondition]}];
(* Standard BCs *)
Do[
If[AsymptoticBoundaryConditions && FindVar[BoundaryCondition[[i,2]],sInt],
(* Asymptotic BCs *)
BCs[[i]]=Solve[Asymptotic[(CompleteSolution[[i]]-BoundaryCondition[[i,2]])//ChopDigits,sInt->0]==0,C[i],Complexes,WorkingPrecision->InternalWorkingPrecisionPrivate]//ChopDigits;
If[BCs[[i]]==={} || FindVar[BCs[[i]],sInt],PrintError["I was not able to fix the asymptotic boundary conditions for MI: "<>ToString[SeaSyde`Private`Debug`MInumber]<>", \[Epsilon] order: "<>ToString[SeaSyde`Private`Debug`EpsOrder]<>". Aborting the computation."];,
BCs[[i]]=BCs[[i,1,1]];
];
,
(* Standard BCs *)
limits[[i]]=Quiet[AnalyticContinuation[CompleteSolution[[i]],KinVariab,LineParametrization,PointExpansion]/.sInt->BCPoint];
If[MatchQ[limits[[i]],Indeterminate],
limits[[i]]=Limit[AnalyticContinuation[CompleteSolution[[i]],KinVariab,LineParametrization,PointExpansion]//Chop,sInt->BCPoint];];
If[NumericQ[limits[[i]]],PrintError["The boundary conditions for MI: "<>ToString[SeaSyde`Private`Debug`MInumber]<>", \[Epsilon] order: "<>ToString[SeaSyde`Private`Debug`EpsOrder]<>" were not sufficient for determining the complete solution. Please provide the asymptotic limit. Aborting the computation."];];
If[MatchQ[limits[[i]],ComplexInfinity] ||MatchQ[limits[[i]],Infinity]|| FindVar[limits[[i]], Infinity]||FindVar[limits[[i]], ComplexInfinity]||MatchQ[limits[[i]],DirectedInfinity[_]]||MatchQ[limits[[i]],Indeterminate],
limits[[i]]=Quiet[AnalyticContinuation[(CompleteSolution[[i]]/.C[i]-> 0)//Chop,KinVariab,LineParametrization,PointExpansion]/.sInt->BCPoint];
If[Abs[limits[[i]]-BoundaryCondition[[i,2]]]<= 1*^-5,BCs[[i]]=(C[i]->0);];
,
BCs[[i]]=Solve[limits[[i]]==BoundaryCondition[[i,2]],C[i],Complexes,WorkingPrecision->InternalWorkingPrecisionPrivate][[1,1]]//ChopDigits;
];
];
,{i,1,Length[BoundaryCondition]}];
If[DependsQ[BCs[[1]],sInt]||MatchQ[BCs,{Null}]||MatchQ[BCs,{}],PrintError["I was not able to fix the boundary conditions for MI: "<>ToString[SeaSyde`Private`Debug`MInumber]<>", \[Epsilon] order: "<>ToString[SeaSyde`Private`Debug`EpsOrder]<>". Aborting the computation."];];
(CompleteSolution//ChopDigits//Expand)/.Join[BCs,{sInt->LineParam-PointExpansion}]//ChopDigits
];

(* Expanding *)
FastSeries[expr_,var_,center_,order_]:=Module[{list,coeff,add,sub,res,subExpToZero,subExpToOne,avoidDoubleCounting,extraOrder},
res=Expand[expr];
list=Cases[res,(Power[base_,expon_]/;(expon<0 && base=!=var)):> Power[base,expon],Infinity]//DeleteDuplicates;

subExpToZero=Map[Rule[#,0]&,list];
res=expr/.subExpToZero;
res=Expand[res];
subExpToOne=Map[Rule[#,0]&,list];
res=res/.var^b_/;b>order->0;

extraOrder=Min[Abs[Cases[Expand[expr/.subExpToOne],Power[a_,b_]:> b]],0];
sub={};
Do[
sub=Join[sub,{Rule[list[[j]],Normal[Series[list[[j]],{var,0,order+extraOrder}]]]}];
,{j,Length[list]}];	
	
avoidDoubleCounting={};
Do[	
coeff=Coefficient[expr,list[[i]]]/.avoidDoubleCounting;
add=Expand[(coeff*list[[i]])/.sub];
add=add/.var^b_/;b>order->0;
res=res+add;
avoidDoubleCounting=Join[avoidDoubleCounting,{list[[i]]:> 0}]
,{i,Length[list]}];
Return[res];
];

(* Integrating function *)
SetAttributes[{MyIntegrateAux},Listable];
IntReplacement={};
MyIntegrate[inputExt__]:=Module[{input=inputExt,LogOrd},
input=(inputExt/.Log[coeff_ *sInt]->Log[coeff]+Log[sInt])//ChopDigits;
LogOrd=Append[GetCases[{input},Log[sInt]^(k_:1)|Log[sInt]^(k_:1):>k],1]//Max;
If[LogOrd>MaxLogOrder,
UpdateIntReps[LogOrd];
];
MyIntegrateAux[input]
];
MyIntegrateAux[a_]:=MyIntegrateAux[a,sInt];
MyIntegrateAux[exp0_/;NumericQ[exp0],var_]:=var exp0;
MyIntegrateAux[exp0_,var_]:=Module[{exp=(Expand@exp0),Out,Const},
exp=exp/.Log[coeff_ *sInt]/;Abs[coeff-1]<=1*^-10->Log[sInt];
Out=exp/.var->b/.IntReplacement;
Const=(Out/.a->0);
Out-Const+b Const/.a->1/.b->var
];

UpdateIntReps[MaxOrd_]:=Module[{},
MaxLogOrder=MaxOrd;
IntReplacement=Join[
Table[Log[x]^n->a Integrate[Log[x]^n,x]/.x->b,{n,MaxLogOrder}],
Table[Log[x]^n x->a Integrate[Log[x]^n x,x]/.x->b,{n,MaxLogOrder}],
Table[Log[x]^n x^m_/;m!=-1->a Integrate[Log[x]^n x^m,x]/.x->b,{n,MaxLogOrder}],
Table[Log[x]^n/x->a Integrate[Log[x]^n x^-1,x]/.x->b,{n,MaxLogOrder}],
{x^m_/;m!=-1->a Integrate[x^m,x]/.x->b},
{x->a Integrate[x,x]/.x->b},
{1/x->a Integrate[1/x,x]/.x->b}
]//Reverse//Expand;
];

DependsQ[a_,b_]:=Length[GetCases[a,b]]>0;
GetCases[expr_,case_]:=expr//Cases[{#},case,Infinity]&//DeleteDuplicates//Sort;

(* Accessing the solution *)
Solution[]:=MasterIntegrals;
SolutionValue[]:=(MasterIntegrals/.Table[VariablesEq[[i]]->CurrentBC[[i]],{i,1,Length[VariablesEq]}])//SetPrec;
SolutionTable[]:=Table[Table[Coefficient[SolutionValue[][[i]],eps,j],{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,NumberMasterIntegrals}];
SolutionExpanded[]:=MasterIntegralsMobius;

EstimateError[var_]:=Module[{radius,bc,sing,solutionTable,newErr},
(* Find bc, singularities and radius *)
Do[
If[var===VariablesEq[[i]],
bc=CurrentBC[[i]];
sing=Singularities[[i]]/.GetPoint[];
Break[];
];
,{i,1,Length[VariablesEq]}];
radius=ExpectedConvergenceRadius[bc,sing,var];

(* solution table *)
solutionTable=Table[Table[Coefficient[Solution[][[i]],eps,j],{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,NumberMasterIntegrals}];

(* estimate error *)
newErr=((solutionTable-(solutionTable/.Power[x_,b_]/;b>=(ExpansionOrderPrivate-2)->0))/.var->bc+radius )//Abs//Max//N;
ErrorEstimate=Max[newErr,ErrorEstimate];
ErrorEstimate
];

(* Graph solution to differential equation *)
CreateGraph[MInumber_,EpsilonOrder_,left_,right_,OtherFunction_:{},AnaliticCont_:False]:=Module[{solution,coeff,plots={}},
If[AnaliticCont,
solution=MasterIntegralsMobius;
coeff=SeriesCoefficient[solution[[MInumber]],{eps,0,EpsilonOrder}];
ReImPlot[{coeff,OtherFunction},{Global`y,left,right},PlotLabel->StringForm["Master Integral `` - Order O(\!\(\*SuperscriptBox[\(\[Epsilon]\), \(``\)]\)) after Mobius Transformation",MasterIntegralsFunctions[[MInumber]],EpsilonOrder],PlotLegends->{{"Series Solution","Exact Solution"}, "ReIm"}]
,
solution=MasterIntegrals;
coeff=Coefficient[solution[[MInumber]],eps,EpsilonOrder];

If[MatchQ[OtherFunction[[0]],List]&&Length[OtherFunction]==0,
ReImPlot[Evaluate[{coeff}/.LastKinematicVariableUsed->Global`x],{Global`x,left,right},PlotLegends->{{"Series Solution"}, "ReIm"},PlotLabel->StringForm["Master Integral `` - Order O(\!\(\*SuperscriptBox[\(\[Epsilon]\), \(``\)]\))",MasterIntegralsFunctions[[MInumber]],EpsilonOrder]]
,
ReImPlot[Evaluate[{coeff,OtherFunction}/.LastKinematicVariableUsed->Global`x],{Global`x,left,right},PlotLegends->{{"Series Solution","Exact Solution"}, "ReIm"},PlotLabel->StringForm["Master Integral `` - Order O(\!\(\*SuperscriptBox[\(\[Epsilon]\), \(``\)]\))",MasterIntegralsFunctions[[MInumber]],EpsilonOrder]]
]
]
];

(* Perform a Mobius trasformation *)
Mobius[serie_,singularities_,xExpansion_,orderX_,var_]:=Module[{xL=Infinity,xR=Infinity,mobTrasformation,yExpansion,rule},
Do[
If[singularities[[i]]<xExpansion, xL=singularities[[i]];];
If[singularities[[-i]]>xExpansion, xR=singularities[[-i]];];
,{i,1,Length[singularities]}];
(* Choose line parameters more wisely when there are more *)
mobTrasformation=MobiusTrasformation[var,y,xL,xR];
yExpansion=Solve[mobTrasformation==xExpansion][[1,1,2]];
rule={var->(Series[mobTrasformation,{y,yExpansion,orderX}])};
Normal[serie/.rule]
];


MobiusTrasformation[oldLineParam_,newLineParam_,xL_,xR_]:=Module[{mob,L,R},
mob=2newLineParam L R/(L-R+newLineParam(L+R));
Limit[mob,{L->xL,R->xR}]
];

PerformMobiusTransformation[var_]:=Module[{MI,serie,newMI,singularit,pointExp},
newMI=Table[0,Length[MasterIntegrals]];
Print["Starting analitical expansion for master integrals"];
Do[
If[
MatchQ[var,VariablesEq[[k]]],
singularit=Singularities[[k]];
pointExp=CurrentBC[[k]];
];
,{k,1,Length[VariablesEq]}];
(* cycle over all MI *)
Do[
Print["Expanding Master Integral number ",i,"/",Length[MasterIntegrals]];
MI=MasterIntegrals[[i]];
(* cycle over all order in \[Epsilon] *)
Do[
Print["- Expanding \[Epsilon] order ",j];
serie=Coefficient[MI,eps,j];
If[NumericQ[serie],
Print["-- The serie is costant so already converges everywhere"];
,
serie=Mobius[serie,singularit,pointExp,Exponent[serie,var]//Round ,var]//Expand;
serie=DropCoefficient[serie];
Print["-- Expanded using Mobius"];
];
newMI[[i]]+=serie*eps^j;
,{j,Exponent[MI,eps,Min],Exponent[MI,eps]}];
,{i,1,Length[MasterIntegrals]}];

MasterIntegralsMobius=newMI;
Print["In order to check the solution after analitical continuation use SolutionExpanded[]"];
];

DropCoefficient[serie_]:=Module[{newSerie=0,coef, nextCoeff},
If[NumericQ[serie],
newSerie=serie
,
Do[
coef=Coefficient[serie,y,i];
If[coef==0,Continue[]];
nextCoeff=Coefficient[serie,y,i+1];
newSerie+=coef*y^i;
If[Abs[nextCoeff/coef]>5,Break[]];
,{i,Exponent[serie,y,Min],Exponent[serie,y]-1}];

];
newSerie
];

(* Transporting BCs *)
(* 
Line Object ={Points[p1,p2,p3], Segments[(p2-p1)t+p1, (p3-p2)t+p2],t}
*)
StraightLine[A_,B_,Param_]:={{(B - A )Param + A}};
CreateLine[PointList_List]:=CreateLine[PointList,tInt];
CreateLine[PointList_List,Param_]:=Module[{lineT={},points},
points=PointList//DropDuplicates;
Do[
lineT=Join[lineT,StraightLine[points[[i]],points[[i+1]],Param]];
,{i,1,Length[points]-1}];
{points/.{List->Points},ToSegments[lineT], lineParam}
];
DropDuplicates[pointList_List]:=Module[{res={}, check={}},
check=Table[Abs[(pointList[[i]]-pointList[[i+1]])]>=10^-$MachinePrecision,{i,1,Length[pointList]-1}];
res=Append[res,pointList[[1]]];
Do[
If[MatchQ[check[[i]],True], res=Append[res,pointList[[i+1]]];];
,{i,1,Length[check]}];
res
];
ToList[Func_[Something__]]:=List[Something];
ToSegments[List[Something__]]:=Segments[Something];

(* Update Boundary Conditions *)
UpdateBoundaryConditions[newPointBC_,Segment_,LineParam_,KinematicVar_,singularities_,FinalPoint_,oldPoint_]:=Module[{NewBoundaryConditions,ind=1,OtherVariablesBC={},closestSing=Infinity,radConvergence=1*^5,direction,sing=singularities,count,nextSing,res,l,pos},
(* If the BC were imposed as asymptotic limit now are no more *)
If[AsymptoticBoundaryConditions,AsymptoticBoundaryConditions=False];
Do[
If[MatchQ[KinematicVar,VariablesEq[[i]]],
CurrentBC[[i]]=newPointBC;
ind=i;
,
OtherVariablesBC=Append[OtherVariablesBC,VariablesEq[[i]]->CurrentBC[[i]]];
];
,{i,1,Length[VariablesEq]}];
CurrentBCLineParam=Solve[Segment== newPointBC, LineParam,WorkingPrecision->InternalWorkingPrecisionPrivate][[1,1,2]]//Chop;

(* If the starting point is a singularity move away *)
If[LogarithmicExpansionPrivate&& CloseToSing[oldPoint,sing],CurrentExpansionPoint=CurrentBCLineParam; ];
If[LogarithmicExpansionPrivate&& !CloseToSing[oldPoint,sing],
(* singolarit\[AGrave] sulla linea *)
res=Table[Reduce[{sing[[i]]==Segment[[1]],Abs[Im[LineParam]]<=1*^-10},LineParam],{i,1,Length[sing]}]/.{(LineParam==val_)->Re[val],False->Infinity};
count=Count[res,Infinity];
res=Sort[res];
res=Drop[res,-count];
If[Length[res]==0,CurrentExpansionPoint=CurrentBCLineParam;,
(* nexsing *)
Do[
If[Abs[sing[[i]]-FinalPoint]<=1*^-10, nextSing=FinalPoint; Break[];];
If[res[[i]]>CurrentBCLineParam, nextSing=Segment[[1]]/.LineParam->res[[i]]; Break[];,nextSing=Segment[[1]]/.LineParam->res[[i]];];
,{i,1,Length[res]}];

If[Length[sing]==1,radConvergence=1*^5; ,
(* closestSing per nextSing *)
l=((Abs[#-nextSing]&)/@sing)//ChopDigits;
l=l/.x_/;x<1*^-10->Infinity;
pos=Position[l,Min[l]][[1,1]];
closestSing=sing[[pos]];
(* radConvergence *)
radConvergence=Abs[(closestSing-nextSing)/RadiusOfConvergencePrivate];
];
If[LogarithmicExpansionPrivate&& Abs[newPointBC-nextSing]<=radConvergence,
CurrentExpansionPoint=Solve[Segment[[1]]== nextSing, LineParam,WorkingPrecision->InternalWorkingPrecisionPrivate][[1,1,2]]//Chop;
,
CurrentExpansionPoint=CurrentBCLineParam;
];
];
,
CurrentExpansionPoint=CurrentBCLineParam;
];
(* Create new Boundary Conditions *)
SystemOfDifferentialEquation=Drop[SystemOfDifferentialEquation, -NumberMasterIntegrals];
NewBoundaryConditions=(MasterIntegrals/.{KinematicVar->newPointBC})//SetPrec;
NewBoundaryConditions=Table[-(MasterIntegralsFunctions[[j]]/.Join[{KinematicVar->newPointBC},OtherVariablesBC])+ NewBoundaryConditions[[j]]==0,{j,1,Length[NewBoundaryConditions]}];
SystemOfDifferentialEquation=Join[SystemOfDifferentialEquation,NewBoundaryConditions];
UpdateSystemEpsilonExpanded[];
];

ExpectedConvergenceRadius[Point_,Sin_,KinematicVariable_]:=Module[{rad=1*^5,pointBoundary},
pointBoundary=Point;
Do[
If[Norm[Sin[[i]]-pointBoundary]>1*^-10,
rad = Min[rad,Norm[pointBoundary-Sin[[i]]]];
];
,{i,1,Length[Sin]}];
rad*1/RadiusOfConvergencePrivate
];

(* 
Input from reduce 
t\[Equal]1   \[Rule] t\[Rule]1
 t\[Equal]2 || t\[Equal]5     \[Rule]  t\[Rule]5
*)
Bigger[solutions_]:=Module[{},
If[MatchQ[solutions[[0]],Or],
Return[solutions[[-1]]/.Equal->Rule]
,
Return[solutions/.Equal->Rule]
]
];

MakeHomogeneus[Equation_,fun_]:=Module[{coeff1,coeff2},
coeff1=Coefficient[Equation[[1,1]],fun];
coeff2=Coefficient[Equation[[1,1]],D[fun,tInt]];
Return[{coeff1 fun + coeff2 D[fun,tInt]==0}];
];

InomogeusPart[equation_]:=Module[{LHS},
LHS=equation/.Equal-> Subtract;
-LHS/.{Subscript[f, _]->(0&)}
];

ClearSeries[series_,param_]:=Module[{},
series/. param^b_/;b>ExpansionOrderPrivate->0
];

ToList[Something_]:=If[Something[[0]]==List, Return[Something],Return[List[Something]]];

LineGood[line_,branches_,sing_,prescription_]:=Module[{segments,solu,lineIsGood=True,c1,c2,pnt},
segments=line[[2]]/.Segments->List;

(* Check if every segment *)
Do[
(* crosses singularity *)
Do[
solu=Solve[{segments[[i,1]]==sing[[j]],tInt>0,tInt< 1}];
If[Length[solu]>= 1, lineIsGood=False];
,{j,1,Length[sing]}];

(* Crosses branches *)
Do[
(* If segment and branch are parallel move over *)
c1=Coefficient[segments[[i,1]],tInt];
c2=Coefficient[branches[[j]],par];
If[Mod[Arg[c1]-Arg[c2],\[Pi]]==0,Continue[];];

(* If are not parallel check if there is intersection *)
solu=Solve[{segments[[i,1]]==branches[[j]],par\[Element]Reals,tInt>=0,tInt<=1,par>=0}];
If[Length[solu]==0,Continue[];];

(* If nor the starting point nor the final point are on the real axes line is not good *)
If[!MatchQ[solu,{{___,tInt-> 0|1,___}}],lineIsGood=False;Continue[];];

(* Take the point not zero and check that the sign of Im is opposite to prescription *)
pnt=segments[[i,1]]/.tInt->0;
If[Im[pnt]==  0, pnt=segments[[i,1]]/.tInt->1];
If[Im[pnt]*prescription<0, lineIsGood=False];
,{j,1,Length[branches]}];
,{i,1,Length[segments]}];
lineIsGood
];

FindSpecialPoint[Singularity_]:=Module[{maxRealSing=-Infinity},
Do[
If[Im[Singularity[[i]]]==0,
maxRealSing=Max[maxRealSing,Singularity[[i]]];
];
,{i,1,Length[Singularity]}];
maxRealSing+1
];

TransportBoundaryConditions[PhaseSpacePoint_List]:=Module[{},
If[Length[PhaseSpacePoint]=!=Length[VariablesEq],PrintError["Please provide a list of length: ",Length[PhaseSpacePoint]];];
Do[
TransportVariable[VariablesEq[[h]],PhaseSpacePoint[[h]]];
,{h,1,Length[PhaseSpacePoint]}];
];

TransportVariable[var_, destinationExt_,PredefinedLineExt_:{}]:=Module[{OtherVarBCs={},linea,SingularitiesForVar,SafeSingularitiesForVar,LogSingularitiesForVar,destination,PredefinedLine,BoundCond},
If[!NumericQ[destinationExt],PrintError["Destination is not a (complex) number."];];
If[AsymptoticBoundaryConditions && !MatchQ[var,AsymptoticVariable],PrintError["The boundary conditions are given as asymptotic limit for ",AsymptoticVariable,", the system can not be solved with respect to ",variable];
];
destination=SetPrecision[destinationExt,InternalWorkingPrecisionPrivate];
PredefinedLine=SetPrecision[PredefinedLineExt,InternalWorkingPrecisionPrivate];

Do[If[MatchQ[var,VariablesEq[[i]]],
BoundCond=CurrentBC[[i]];
SingularitiesForVar=Singularities[[i]];
LogSingularitiesForVar=LogarithmicSingularities[[i]];
SafeSingularitiesForVar=SafeSingularities[[i]];
,
OtherVarBCs=Join[OtherVarBCs,{VariablesEq[[i]]->CurrentBC[[i]]}];
];
,{i,1,Length[VariablesEq]}];

If[Abs[BoundCond-destination]<1*^-5 && PredefinedLine==={},
If[MasterIntegrals===MasterIntegralsFunctions,
SolveSystem[var];,
PrintInfo["The system is already solved in ",var,"=",destination//N];
];
Return[];
];

SingularitiesForVar=Sort[SingularitiesForVar/.OtherVarBCs]//DeleteDuplicates;
SafeSingularitiesForVar=Sort[SafeSingularitiesForVar/.OtherVarBCs]//DeleteDuplicates;
LogSingularitiesForVar=Sort[LogSingularitiesForVar/.OtherVarBCs]//DeleteDuplicates;

If[MatchQ[Length[PredefinedLine],0],
If[MatchQ[LogarithmicExpansionPrivate,False],
linea=DeterminePath[var,BoundCond//SetPrec,destination//SetPrec,LogSingularitiesForVar,SafeSingularitiesForVar]//SetPrec//ChopDigits;
PrintInfo["Moving following these points: ",linea[[1]]/.Points->List//N, ", avoiding singularities. Here you can see the path in the complex plane for the kinematic variable ",var];
Print[ShowPath[LogSingularitiesForVar,SafeSingularitiesForVar,linea,var]];
,
linea=DeterminePathLog[var,BoundCond,destination//SetPrec,LogSingularitiesForVar,SafeSingularitiesForVar]//SetPrec//ChopDigits;
PrintInfo["Moving following these points: ",linea[[1]]/.Points->List//N, ". NOT avoiding singularities. Here you can see the path in the complex plane for the kinematic variable ",var];
Print[ShowPath[LogSingularitiesForVar,SafeSingularitiesForVar,linea,var]];
];
SolveAlongLine[linea,var,SingularitiesForVar];
,
PrintInfo["Moving following these points: ",PredefinedLine[[1]]/.Points->List//N, ", avoiding singularities. Here you can see the path in the complex plane for the kinematic variable ",var];
Print[ShowPath[LogSingularitiesForVar,SafeSingularitiesForVar,PredefinedLine,var]];
SolveAlongLine[PredefinedLine,var,SingularitiesForVar];
];
];

ShowPath[LogSing_,SafeSing_,Path_,Variable_]:=Module[{singularity,RedLines={},Lines={},PathFound={},ListPointComplex={},ListPoint={},singComplete,PointsSing},
Do[
singularity=LogSing[[i]];
RedLines=Append[RedLines,Line[{{(singularity//Re)-100,singularity//Im},{singularity//Re,singularity//Im}}]];
,{i,1,Length[LogSing]}];
Lines=Join[Lines,Table[Graphics[{RGBColor[1,0,0],RedLines[[i]]}],{i,1,Length[RedLines]}]];
ListPointComplex=Path[[1]]/.SeaSyde`Private`Points->List;
Do[
ListPoint=Append[ListPoint,{ListPointComplex[[i]]//Re,ListPointComplex[[i]]//Im}];
,{i,1,Length[ListPointComplex]}];
PathFound={Graphics[{RGBColor[0,0,0],Line[ListPoint]}]};
singComplete=Join[LogSing,SafeSing];
PointsSing=Table[Graphics[{RGBColor[255,0,0],Inset[Style["\[Cross]",15],{Re[singComplete[[i]]],Im[singComplete[[i]]]}]}],{i,1,Length[singComplete]}];
Show[Join[Lines,PathFound,PointsSing],Axes->True,PlotLabel->"Kinematic variable: "<>ToString[Variable],AxesLabel->{"Re "<>ToString[Variable],"Im "<>ToString[Variable]},PlotRange->{{Min[Re/@ListPointComplex]-2,Max[Re/@ListPointComplex]+2},{Min[Im/@ListPointComplex]-2,Max[Im/@ListPointComplex]+2}}]
];

SolveAlongLine[LineObject_List,KinVar_,Singul_]:=Module[{Points =ToList[LineObject[[1]]], Segments=ToList[LineObject[[2]]],LineParam=LineObject[[3]],newPoint,NewBoundaryConditions,segment,radius,newPointLineParam,oldPoint,index,lastPoint,dir,pointBoundCond,line,lasterCentre,l,pos,closestSing,rad,LogarithmicExpansionPrivateTemp,nextPT,pointBegin},

LogarithmicExpansionPrivateTemp=LogarithmicExpansionPrivate;

CurrentExpansionPoint=0;
If[LogarithmicExpansionPrivate && CloseToSing[Points[[1]],Singul],
Do[
If[MatchQ[KinVar,VariablesEq[[i]]],
pointBoundCond=CurrentBC[[i]];
Break[];
];
,{i,1,Length[VariablesEq]}];
CurrentBCLineParam=Solve[Segments[[1,1]]== pointBoundCond, LineParam,WorkingPrecision->InternalWorkingPrecisionPrivate][[1,1,2]]//Chop;
,
CurrentBCLineParam=0;
];

(* loop over segments *)
Do[
PrintInfo["Moving from the point ",KinVar,"=", Points[[i]]//N, " to ",KinVar,"=",Points[[i+1]]//N, ", along the line ",KinVar,"=",Segments[[i,1]]//N];
(* Solve system of differential equation *)
Do[
If[MatchQ[KinVar,VariablesEq[[k]]],index=k; Break[];];
,{k,1,Length[VariablesEq]}];
oldPoint=CurrentBC[[index]];
SolveSeriesExpansion[Segments[[i,1]],KinVar,False];
pointBegin=Segments[[i,1]]/.LineParam->CurrentExpansionPoint;
radius=ExpectedConvergenceRadius[pointBegin,Singul,KinVar];
newPointLineParam=Reduce[{Norm[pointBegin-Segments[[i]]]==radius,Element[LineParam, Reals],LineParam>= 0},LineParam]//Num//Bigger;
newPoint=Segments[[i]]/.newPointLineParam;

While[Norm[oldPoint-Points[[i+1]]]>= radius ,
UpdateBoundaryConditions[newPoint[[1]],Segments[[i]],LineParam,KinVar,Singul//Sort,Points[[i+1]],oldPoint];
PrintInfo["The new point is: ",KinVar,"=",Segments[[i,1]]/.{LineParam->CurrentExpansionPoint}//N];
oldPoint=Segments[[i,1]]/.{LineParam->CurrentExpansionPoint};

SolveSeriesExpansion[Segments[[i,1]],KinVar,False];
radius=ExpectedConvergenceRadius[oldPoint,Singul,KinVar];
newPointLineParam=Reduce[{Norm[oldPoint-Segments[[i]]]==radius,Element[LineParam, Reals],LineParam>= 0},LineParam]//Num//Bigger;
newPoint=Segments[[i]]/.newPointLineParam;
(* If the last point is a singularity and I am close to it Break[]; *)
If[CloseToSing[Points[[i+1]],Singul//Sort],
l=((Abs[#-Points[[i+1]]]&)/@Singul)//ChopDigits;
l=l/.x_/;x<1*^-10->Infinity;
pos=Position[l,Min[l]][[1,1]];
closestSing=Singul[[pos]];
rad=Abs[(closestSing-Points[[i+1]])/RadiusOfConvergencePrivate];
If[Abs[newPoint[[1]]-Points[[i+1]]]<= rad,Break[];];
];
];

If[i!=Length[Segments],
nextPT=Points[[i+1]];
If[CloseToSing[Points[[i+1]],Singul],
UpdateBoundaryConditions[newPoint[[1]],Segments[[i]],LineParam,KinVar,Singul//Sort,Points[[i+1]],oldPoint];

PrintInfo["The new point is: ",KinVar,"=",Segments[[i,1]]/.{LineParam->CurrentExpansionPoint}//N];
oldPoint=Segments[[i,1]]/.{LineParam->CurrentExpansionPoint};
SolveSeriesExpansion[Segments[[i,1]],KinVar,False];

radius=ExpectedConvergenceRadius[oldPoint,Singul,KinVar];
newPointLineParam=Reduce[{Norm[oldPoint-Segments[[i+1]]]==radius,Element[LineParam, Reals],LineParam>= 0},LineParam]//Num//Bigger;
nextPT=Segments[[i+1,1]]/.newPointLineParam;
];
UpdateBoundaryConditions[nextPT,Segments[[i+1]],LineParam,KinVar,Singul//Sort,Points[[i+1]],oldPoint];
];
,{i,1,Length[Segments]}];

(* I want a series centered in the last point *)
If[CloseToSing[Points[[-1]],Singul//Sort],
PackageConfiguration["LogarithmicExpansion"]=True;
line=StraightLine[newPoint[[1]],Points[[-1]],LineParam][[1]];lastPoint=newPoint[[1]];
,
line={LineParam+Points[[-1]]};lastPoint=Points[[-1]];
];
lasterCentre=(Segments[[-1,1]]/.tInt->CurrentExpansionPoint);
UpdateBoundaryConditions[lastPoint,line,LineParam,KinVar,Singul//Sort,Points[[-1]],oldPoint];
If[Abs[lasterCentre-Points[[-1]]]>1*^-10,
If[!CloseToSing[Points[[-1]],Singul],CurrentExpansionPoint=0;];
SolveSeriesExpansion[line[[1]],KinVar,False];
];
If[CloseToSing[Points[[-1]],Singul//Sort], PackageConfiguration["LogarithmicExpansion"]=LogarithmicExpansionPrivateTemp;];
PrintInfo["I arrived at ",KinVar,"=",Points[[-1]]//N, ". The error estimate is: ",EstimateError[KinVar],".\nUse Solution[], SolutionValue[] or SolutionTable[] to access the solution."];
];

CloseToSing[point_,sing_]:=Module[{},
If[ContainsAny[Cases[sing, x_/;Abs[x-point]<= 1*^-10-> True],{True}], True,False]
];

AnalyticContinuation[Series_,KinematicVariable_,LineParametriz_,PointExp_]:=Module[{prescription,currentBoundary,lineCoefficient},
If[!LogarithmicExpansionPrivate,Return[Series];];
Do[
If[
MatchQ[KinematicVariable,VariablesEq[[k]]],
prescription=DeltaPrescription[[k]];
currentBoundary=CurrentBC[[k]];
Break[];
];
,{k,1,Length[VariablesEq]}];
lineCoefficient=Coefficient[LineParametriz,tInt,1];
If[Abs[Im[LineParametriz/.tInt->PointExp]]=!=0,Return[Series]];
If[Coefficient[LineParametriz,tInt,1]*prescription>0,Return[Series];];
Series/.{Log[arg__]->Log[arg]-2\[Pi] I Subscript[\[Theta], m][arg],Power[arg__,Rational[a_,2]]->(Subscript[\[Theta], p][arg]-Subscript[\[Theta], m][arg])Power[arg,Rational[a,2]]}
];

NotCloseToSing[From_,To_,Singularities_]:=Module[{Result=True},
Do[
If[Re[From]<Re[To] &&Re[From]<Re[Singularities[[i]]]&&Re[Singularities[[i]]]<Re[To],Result=False;];
If[Re[To]<Re[From] &&Re[To]<Re[Singularities[[i]]]&&Re[Singularities[[i]]]<Re[From], Result=False;];
,{i,1,Length[Singularities]}];
Result
];

GetPoint[]:=Table[VariablesEq[[i]]->CurrentBC[[i]],{i,1,Length[VariablesEq]}];

CheckSingularities[]:=Module[{currBCforOtherVar={},sing,singLess={},singMore={},singComplex={},currBcforVar,LogarithmicSingularitiesTmp,SafeSingularitiesTmp},
(* Reset just in case *)
LogarithmicSingularitiesTmp={};
SafeSingularitiesTmp={};

(* Spread singularities *)
SpreadSingularities[];

(* Save current configuration ad position *)
SaveCurrentState[];
PackageConfiguration["LogarithmicExpansion"]=False;

Do[
PrintInfo["Checking the logarithmic behaviour for all the singularities for the kinematic variable ",VariablesEq[[i]]];
PrintInfo["The possible singularities are in ", Singularities[[i]]];

LogarithmicSingularitiesTmp=Append[LogarithmicSingularitiesTmp,{}];
SafeSingularitiesTmp=Append[SafeSingularitiesTmp,{}];

(* Find some useful information *)
currBCforOtherVar={};
Do[
If[MatchQ[VariablesEq[[i]],VariablesEq[[j]]],
currBcforVar=CurrentBC[[j]];
,
currBCforOtherVar=Append[currBCforOtherVar,VariablesEq[[j]]-> CurrentBC[[j]]];
];
,{j,1,Length[VariablesEq]}];
sing={Singularities[[i]],Singularities[[i]]/.currBCforOtherVar};

(* Divide into real>BC, real<BC and complex *)
singMore={};
singLess={};
singComplex={};
Do[
If[Im[sing[[2,l]]]==0,
If[Re[sing[[2,l]]]>=currBcforVar,
singMore=Append[singMore,{sing[[1,l]],sing[[2,l]]}];
,
singLess=Append[singLess,{sing[[1,l]],sing[[2,l]]}];
];
,
singComplex=Append[singComplex,sing[[1,l]]];
];
,{l,1,Length[sing[[1]]]}];

(* Check real more *)
singMore=Sort[singMore,#1[[2]]<#2[[2]]&];
singMore=Table[singMore[[k,1]],{k,1,Length[singMore]}];
Do[
If[IsSingularityLogarithmic[singMore[[j]],VariablesEq[[i]]],
LogarithmicSingularitiesTmp[[i]]=Append[LogarithmicSingularitiesTmp[[i]],singMore[[j]]]; PrintInfo["The singularity ",singMore[[j]]," for the variable ",VariablesEq[[i]]," is LOGARITHMIC"];
,
SafeSingularitiesTmp[[i]]=Append[SafeSingularitiesTmp[[i]],singMore[[j]]];PrintInfo["The singularity ",singMore[[j]]," for the variable ",VariablesEq[[i]]," is SAFE"];
];
,{j,1,Length[singMore]}];
RestoreState[];

(* check real less *)
singLess=Sort[singLess,#1[[2]]>#2[[2]]&];
singLess=Table[singLess[[k,1]],{k,1,Length[singLess]}];
Do[
If[IsSingularityLogarithmic[singLess[[j]],VariablesEq[[i]]],
LogarithmicSingularitiesTmp[[i]]=Append[LogarithmicSingularitiesTmp[[i]],singLess[[j]]];
PrintInfo["The singularity ",singLess[[j]]," for the variable ",VariablesEq[[i]]," is LOGARITHMIC"];
,
SafeSingularitiesTmp[[i]]=Append[SafeSingularitiesTmp[[i]],singLess[[j]]];
PrintInfo["The singularity ",singLess[[j]]," for the variable ",VariablesEq[[i]]," is SAFE"];
];
,{j,1,Length[singLess]}];
RestoreState[];

(* check complex *)
Do[
If[IsSingularityLogarithmic[singComplex[[j]],VariablesEq[[i]]],
LogarithmicSingularitiesTmp[[i]]=Append[LogarithmicSingularitiesTmp[[i]],singComplex[[j]]];
PrintInfo["The singularity ",singComplex[[j]]," for the variable ",VariablesEq[[i]]," is LOGARITHMIC"];
,
SafeSingularitiesTmp[[i]]=Append[SafeSingularitiesTmp[[i]],singComplex[[j]]];
PrintInfo["The singularity ",singComplex[[j]]," for the variable ",VariablesEq[[i]]," is SAFE"];
];
RestoreState[];
,{j,1,Length[singComplex]}];

,{i,1,Length[VariablesEq]}];

RestoreLogarithmicExpansion[];
PrintInfo["LogarithmicSingularities ->",LogarithmicSingularitiesTmp];
PrintInfo["SafeSingularities -> ",SafeSingularitiesTmp];
PackageConfiguration["LogarithmicSingularities"]=LogarithmicSingularitiesTmp;
PackageConfiguration["SafeSingularities"]=SafeSingularitiesTmp;
];


SaveCurrentState[]:=Module[{},
SystemOfDifferentialEquationBackup = SystemOfDifferentialEquation;
SystemEpsilonExpandedBackup = SystemEpsilonExpanded;
MasterIntegralsBackup= MasterIntegrals;
MasterIntegralsMobiusBackup=MasterIntegralsMobius;
CurrentBCBackup=CurrentBC;
lineBackup=line;
lineParamBackup=lineParam;
CurrentExpansionPointBackup=CurrentExpansionPoint;
CurrentBCLineParamBackup=CurrentBCLineParam;
LastKinematicVariableUsedBackup=LastKinematicVariableUsed;
KinematicParametersBackup=KinematicParameters;
AsymptoticBoundaryConditionsBackup=AsymptoticBoundaryConditions;
AsymptoticVariableBackup=AsymptoticVariable;
LogarithmicExpansionPrivateBackup=LogarithmicExpansionPrivate;
];

RestoreLogarithmicExpansion[]:=Module[{},
PackageConfiguration["LogarithmicExpansion"]=LogarithmicExpansionPrivateBackup;
];

RestoreState[]:=Module[{},
SystemOfDifferentialEquation=SystemOfDifferentialEquationBackup;
SystemEpsilonExpanded=SystemEpsilonExpandedBackup ;
MasterIntegrals=MasterIntegralsBackup;
MasterIntegralsMobius=MasterIntegralsMobiusBackup;
CurrentBC=CurrentBCBackup;
line=lineBackup;
lineParam=lineParamBackup;
CurrentExpansionPoint=CurrentExpansionPointBackup;
CurrentBCLineParam=CurrentBCLineParamBackup;
LastKinematicVariableUsed=LastKinematicVariableUsedBackup;
KinematicParameters=KinematicParametersBackup;
AsymptoticBoundaryConditions=AsymptoticBoundaryConditionsBackup;
AsymptoticVariable=AsymptoticVariableBackup;
];

IsSingularityLogarithmic[singExt_,var_]:=Module[{sing,currBCforVar,currBCforOtherVar={},index=1,rad,sol1,sol2,singExact},
PrintInfo["Checking sing ", singExt, " for variable ",var];

Do[
If[MatchQ[var,VariablesEq[[i]]],
currBCforVar=CurrentBC[[i]];
singExact=DeleteCases[Singularities[[i]],singExt];
index=i;
,
currBCforOtherVar=Append[currBCforOtherVar,VariablesEq[[i]]-> CurrentBC[[i]]];
];
,{i,1,Length[VariablesEq]}];
sing=singExt/.currBCforOtherVar;

(* Find closest sing \[Rule] find radius *)
singExact=(Abs[#-sing]/RadiusOfConvergencePrivate)&/@(singExact/.currBCforOtherVar);
rad=Min[singExact//Min,0.5];

TransportVariable[var, sing+rad];
sol1=Table[Table[Coefficient[SolutionValue[][[i]],eps,j],{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,NumberMasterIntegrals}];
TransportVariable[var, sing+rad, CreateLine[{sing+rad, sing+rad+rad I, sing-rad+rad I,sing-rad-rad I, sing+rad-rad I,sing+rad}]];
sol2=Table[Table[Coefficient[SolutionValue[][[i]],eps,j],{j,MinEpsExponent,EpsilonOrderPrivate}],{i,1,NumberMasterIntegrals}];
If[((sol1-sol2)//Abs//Max)>1*^-10,Return[True];];
Return[False];
];

FindLog[expr_] := Module[{temp},
temp = Hold[expr] /. Log[_] -> 0;
If[(temp === Hold[expr]), False,True]
];

FindSqrt[expr_] := Module[{temp},
temp = Hold[expr] /. Sqrt[_] -> 0;
If[(temp === Hold[expr]), False,True]
];

SpreadSingularities[]:=Module[{varBC,currBC,index,currBCforOtherVar={},currentSing,Destination=CurrentBC,var,counter,offset=0},
PrintInfo["Checking if some singularities overlap"];
Do[
currBCforOtherVar={};
Do[
If[MatchQ[VariablesEq[[i]],VariablesEq[[j]]],
currentSing=Singularities[[j]];
var=VariablesEq[[j]];
,
currBCforOtherVar=Append[currBCforOtherVar,VariablesEq[[j]]-> CurrentBC[[j]]];
];
,{j,1,Length[VariablesEq]}];

(* Guardo le singolarit\[AGrave] per le altre variabili, se con la BC attuale ho dei doppioni, cambio *)
counter=1;
While[counter<=100 && !MatchQ[(currentSing/.currBCforOtherVar)//N,DeleteDuplicates[(currentSing/.currBCforOtherVar)//N]],
(* cambia sing *)
varBC=currBCforOtherVar[[1,1]];
currBC=currBCforOtherVar[[1,2]];
currBCforOtherVar=Delete[currBCforOtherVar,1];
If[currBC>=0, currBC=currBC+1.;,currBC=currBC-1.;];
currBCforOtherVar=Insert[currBCforOtherVar,varBC->currBC,1];
counter++;
];

offset=0;
Do[
If[MatchQ[var,VariablesEq[[j]]],offset=1;Continue[];];
Destination[[j]]=currBCforOtherVar[[j-offset,2]];
,{j,1,Length[VariablesEq]}];

,{i,1,Length[VariablesEq]}];

PrintInfo["Transporting Boundary conditions to ",Table[VariablesEq[[i]]-> Destination[[i]]//N,{i,1,Length[VariablesEq]}]];
Do[
If[Abs[Destination[[i]]-CurrentBC[[i]]]>1*^-10, TransportVariable[VariablesEq[[i]],Destination[[i]]];];
,{i,1,Length[VariablesEq]}];
];

(*Selects,among SingVert,the Vertical branches that are possible obstacles in going from'From' to'Destination'*)
CheckVerticalBranch[From_,Destination_,SingVert_]:=Module[{out={}},
Do[
If[(Re[From]<=Re[SingVert[[i]]]<=Re[Destination]||Re[Destination]<=Re[SingVert[[i]]]<=Re[From])&&((Abs[Im[SingVert[[i]]]]<=Abs[Im[From]]||Abs[Im[SingVert[[i]]]]<=Abs[Im[Destination]])&&(If[Im[From]*Im[Destination]>0,Im[From]*Im[SingVert[[i]]]>0,True])),
out=Join[out,{SingVert[[i]]}];
];
,{i,1,Length[SingVert]}];
out
];

(*Selects,among SingHor,the Horizontal branches that are possible obstacles in going from'From' to'Destination'*)
CheckHorizontalBranch[From_,Destination_,SingHor_]:=Module[{out={}},
Do[
If[(Im[From]<=Im[SingHor[[i]]]<=Im[Destination]||Im[Destination]<=Im[SingHor[[i]]]<=Im[From])&& (Re[SingHor[[i]]]>=Re[Destination]|| Re[SingHor[[i]]]>=Re[From]),
out=Join[out,{SingHor[[i]]}];
];
,{i,1,Length[SingHor]}];
out
];

(*Checks that the vertical path between'from' to'to' is not along a vertical branch generated by the singularities in'Sing'.If'to' is the same as'destination',simply checks if any of the singularities are on the path,not if the path is on the branch*)
CheckNotOnBranchV[from_,to_,Destination_,Sing_]:=Module[{flag=True},
If[to==Destination,
Do[
If[Re[from]==Re[Sing[[i]]]&&Re[to]==Re[Sing[[i]]]&&(Abs[Im[from]]<Abs[Im[Sing[[i]]]]<Abs[Im[to]]||Abs[Im[to]]<Abs[Im[Sing[[i]]]]<Abs[Im[from]]),
flag=False];
,{i,1,Length[Sing]}],
Do[
If[Re[from]==Re[Sing[[i]]]&&Re[to]==Re[Sing[[i]]]&& (Abs[Im[Sing[[i]]]]<=Abs[Im[to]]||Abs[Im[Sing[[i]]]]<=Abs[Im[from]]),
flag=False];
,{i,1,Length[Sing]}]
];
flag
];

(*Checks that the horizontal path between'from' to'to' is not along a horizontal branch generated by the singularities in'Sing'.If'to' is the same as'destination',simply checks if any of the singularities are on the path,not if the path is on the branch*)
CheckNotOnBranchH[from_,to_,Destination_,Sing_]:=Module[{flag=True},
If[to==Destination,
Do[
If[Im[from]==Im[Sing[[i]]]&&Im[to]==Im[Sing[[i]]]&&(Re[from]<Re[Sing[[i]]]<Re[to]||Re[to]<Re[Sing[[i]]]<Re[from]),flag=False];
,{i,1,Length[Sing]}],
Do[
If[Im[from]==Im[Sing[[i]]]&&Im[to]==Im[Sing[[i]]]&&(Re[from]<=Re[Sing[[i]]]||Re[to]<=Re[Sing[[i]]]),flag=False];
,{i,1,Length[Sing]}]
];
flag
];

(*Selects the singularities among the ones in'Sing' that are on the path from'from' to'to'.*)CheckNotOnSafeV[from_,to_,Sing_]:=Module[{output={}},Do[If[Re[from]==Re[Sing[[i]]]&&Re[to]==Re[Sing[[i]]]&&(Im[from]<=Im[Sing[[i]]]<=Im[to]||Im[to]<=Im[Sing[[i]]]<=Im[from]),output=Join[output,{Sing[[i]]}]];,{i,1,Length[Sing]}];
output];
CheckNotOnSafeH[from_,to_,Sing_]:=Module[{output={}},Do[If[Im[from]==Im[Sing[[i]]]&&Im[to]==Im[Sing[[i]]]&&(Re[from]<=Re[Sing[[i]]]<=Re[to]||Re[to]<=Re[Sing[[i]]]<=Re[from]),output=Join[output,{Sing[[i]]}]];,{i,1,Length[Sing]}];
output];

DeterminePath[Var_,FromExt_,DestinationExt_,LogSingExt_,SafeSingExt_:{}]:=Module[{LogSing,LogSingIm,LogSingRe,SafeSing,Sing,Prescription,CorrStart=0,CorrEnd=0,Corr,Height,maxReSing=-Infinity,moreRight,moreLeft,pointsList={},From=FromExt,Destination=DestinationExt,HeightStart,HeightEnd,tmp,offsetStart=0,offsetEnd=0,prescrStart=1,prescrEnd=1,offset=0,sgnStart=1,sgnEnd=1,sgn=1},
LogSing=LogSingExt//SetPrec;
SafeSing=DeleteCases[SafeSingExt,x_/;(x==From||x==Destination)]//SetPrec;
Sing=Join[LogSing,SafeSing];

(* I\[Delta] prescription *)
Do[If[VariablesEq[[i]] == Var, Prescription =DeltaPrescription[[i]]], {i, 1, Length[VariablesEq]}];
If[Prescription===-1,
From=Conjugate[From];
Destination=Conjugate[Destination];
LogSing=Conjugate[LogSing];
SafeSing=Conjugate[SafeSing];
Sing=Conjugate[Sing];
];
AppendTo[pointsList,From];

(* Find Corridors *)
LogSingIm=Sort[LogSing//Im]//DeleteDuplicates;
AppendTo[LogSingIm,Infinity];
PrependTo[LogSingIm,-Infinity];

While[Im[From]>= LogSingIm[[CorrStart+1]],CorrStart++;];
While[Im[Destination]>= LogSingIm[[CorrEnd+1]],CorrEnd++;];

If[CorrStart===1,offsetStart=1;sgnStart=-1;];
If[CorrEnd===1,offsetEnd=1;sgnEnd=-1;];

(* Start & End in the same corridor *)
If[CorrStart===CorrEnd,
(* Is there a singularity between them *)
If[Length[Cases[Sing, x_/;((Min[Re[From],Re[Destination]]<Re[x]< Max[Re[From],Re[Destination]])&&(Min[Im[From],Im[Destination]]-0.5<Im[x]<Max[Im[From],Im[Destination]]+0.5))]]>0,
(* are both in the central third? *)

Height=Min[LogSingIm[[CorrStart+1]]-LogSingIm[[CorrStart]],1];

If[(LogSingIm[[CorrStart]]+Height/3<=Im[From]<=LogSingIm[[CorrStart+1]] -Height/3)&&(LogSingIm[[CorrStart]]+Height/3<=Im[Destination]<=LogSingIm[[CorrStart+1]] -Height/3),
pointsList={From,Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
,
pointsList={From,Re[From]+I  (LogSingIm[[CorrStart+offsetStart]]+sgnStart Height/2),Re[Destination]+ I (LogSingIm[[CorrStart+offsetStart]]+sgnStart Height/2),Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];
,
pointsList={From,Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];
];

(* They are not in the same corridor *)
tmp=LogSingIm[[Min[CorrStart,CorrEnd]+1;;Max[CorrStart,CorrEnd]]];
Do[maxReSing=Max[Cases[LogSing,x_/;Abs[Im[x]-tmp[[i]]]<=1*^-15]//Re//Max,maxReSing],{i,1,Length[tmp]}];
HeightStart=Min[LogSingIm[[CorrStart+1]]-LogSingIm[[CorrStart]],1];
HeightEnd=Min[LogSingIm[[CorrEnd+1]]-LogSingIm[[CorrEnd]],1];

(* One or both of them to the right *)
If[Re[From]>= Re[Destination],
moreRight=From;moreLeft=Destination;Corr=CorrEnd;Height=HeightEnd;offset=offsetEnd;sgn=sgnEnd;,
moreRight=Destination;moreLeft=From;Corr=CorrStart;Height=HeightStart;offset=offsetStart;sgn=sgnStart;
];

If[Re[moreRight]>=( maxReSing+1),
(* If the smallest one is to the left of maxReSing+1, check is it is in the third *)
If[(Re[moreLeft]<( maxReSing+1))&&!(LogSingIm[[Corr]]+Height/3<=Im[moreLeft]<=LogSingIm[[Corr+1]] -Height/3),
If[moreLeft===From,
pointsList={From,Re[From]+I (LogSingIm[[Corr+offset]]+sgn Height/2),Re[moreRight]+(LogSingIm[[Corr+offset]]+sgn Height/2)prescrEnd I,Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];
pointsList={From,Re[moreRight]+(LogSingIm[[Corr+offset]]+sgn Height/2) I,Re[Destination]+I (LogSingIm[[Corr+offset]]+sgn Height/2),Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];
pointsList={From,Re[moreRight]+Im[moreLeft]I,Destination};
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];

HeightStart=Min[LogSingIm[[CorrStart+1]]-LogSingIm[[CorrStart]],1];
HeightEnd=Min[LogSingIm[[CorrEnd+1]]-LogSingIm[[CorrEnd]],1];
AppendTo[pointsList,Re[From]+ I (LogSingIm[[CorrStart+offsetStart]]+sgnStart HeightStart/2)];
AppendTo[pointsList,maxReSing+0.5+ I (LogSingIm[[CorrStart+offsetStart]]+sgnStart HeightStart/2)];
AppendTo[pointsList,maxReSing+0.5+ I (LogSingIm[[CorrEnd+offsetEnd]]+sgnEnd HeightEnd/2)];
AppendTo[pointsList,Re[Destination] +I  (LogSingIm[[CorrEnd+offsetEnd]]+sgnEnd HeightEnd/2)];
AppendTo[pointsList,Destination];
If[Prescription===-1,Return[CreateLine[Conjugate[pointsList]]];];
Return[CreateLine[pointsList]];
];

(* DeterminePathLog *)
DeterminePathLog[Var_,From_,Destination_,SingExt_,SafeSingExt_:{}]:=Module[{upMargin, downMargin,leftMargin,rightMargin,singBox={},tempStart,pointsList={From},counter=0},
(* If start and end have the same imaginary part, than the path is a horizontal straight line *)
If[Im[From]==Im[Destination], Return[CreateLine[{From,Destination}]];];
(* Find all the singularities in the right-infinite box *)
upMargin=Max[Im[From],Im[Destination]];
downMargin=Min[Im[From],Im[Destination]];
leftMargin=Min[Re[From],Re[Destination]];
rightMargin=Max[Re[From],Re[Destination]];
Do[
If[Re[SingExt[[i]]]>= leftMargin && downMargin<= Im[SingExt[[i]]]<= upMargin, singBox=Append[singBox,SingExt[[i]]]];
,{i,1,Length[SingExt]}];

Do[
If[leftMargin<=Re[SafeSingExt[[i]]]<= rightMargin && downMargin<= Im[SafeSingExt[[i]]]<= upMargin, singBox=Append[singBox,SafeSingExt[[i]]]];
,{i,1,Length[SafeSingExt]}];

If[MatchQ[singBox,{}],Return[DeterminePath[Var,From,Destination,SingExt,SafeSingExt]];];

tempStart=From;
singBox=Append[singBox,Destination];

While[tempStart!=Destination && counter< 100,
singBox=Sort[singBox,myDistance[#1,tempStart]<myDistance[#2,tempStart]&];
pointsList=Append[pointsList,singBox[[1]]];
tempStart=singBox[[1]];
singBox=Drop[singBox,1];
counter++;
];
If[counter>=100,Print["Error counter ", counter]];
Return[CreateLine[pointsList]];
];

myDistance[sing_,point_]:=Module[{},
If[Re[sing]>= Re[point],Return[Abs[Im[point]-Im[sing]]];];
Return[Abs[point-sing]];
];

End[];
EndPackage[];



